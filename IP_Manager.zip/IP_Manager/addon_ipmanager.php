<?PHP
#ACLS:edit-dns
#WHMADDON:ipmanager:IP Manager
header("Location: ".$_ENV{'cp_security_token'}."/ipmanager/index.php");
?>