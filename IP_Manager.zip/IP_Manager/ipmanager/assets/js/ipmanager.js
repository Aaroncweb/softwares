	if(typeof jQuery.parseJSON=='undefined') {
		jQuery.parseJSON = function(json) {
			  if(typeof JSON != 'undefined' && typeof JSON.parse === 'function') return JSON.parse(json);
			  else return eval('(' + json + ')');
		};
	}
	
	var IPManager = IPManager || {};
	IPManager.Accounts = {	
	
			search_kw: '',
			search_items: [],
			search_nflag: false,
			
			getList: function(silent, cur_page){
					if(!silent) $('#accounts-list').html('Loading accounts...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=accounts_list',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													if(typeof _o.items=='boolean' && !_o.items)
													{
															$('#accounts-list').html('An error occurred. <a href="javascript:void(0);" onclick="IPManager.Accounts.getList('+silent+', '+cur_page+');">Reload</a>');
															return false;
													}
													IPManager.Accounts.search_nflag = false;
													IPManager.Accounts.search_items = [];
													$('#accounts-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#accounts-list').data('items', queue);
													IPManager.Accounts.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
					
			},
			
			displayItems: function(cur_page){					
					var items = (typeof IPManager.Accounts.search_items!=='undefined' && IPManager.Accounts.search_items.length>0) ? IPManager.Accounts.search_items : $('#accounts-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.Accounts.search_nflag)
					{
							if($('#search-container').length>0 && $('#accounts-list').data('items').length==0) $('#search-container').remove();
							listing = '<table cellspacing="0" cellpadding="0"><tr><td>No accounts found.</td></tr></table>';
							$('#accounts-list').html(listing);
					}
					else
					{
							var wordwrap = 15;
							var start 	 = 0;
							var end 	 = items.length;
							var listing  = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item 	= items[i];
											listing = listing + '<tr>\
												<td>'+item.domain+'</td>\
												<td>'+item.ip+'</td>\
												<td><a title="Change '+item.domain+' IP Address" href="javascript:void(0);\" onclick="IPManager.IP.popupList(\''+item.user+'\',\''+item.domain+'\',\''+item.ip+'\');">Change IP</a></td>\
											</tr>';
									}
							}
							if(listing!='')
							{
								var frm = '<div id="search-container" style="margin-bottom:15px;margin-top:25px;"><fieldset><legend>Search</legend><form id="search-form" autocomplete="off" action="" method="post" onsubmit="IPManager.Accounts.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"></form></fieldset>\
											<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.Accounts.search(); });</script></div>';
								if($('#search-container').length==0) $('#accounts-list').before(frm);
								listing = '<table cellspacing="5" cellpadding="2">\
											<tr>\
												<th>Domain</th>\
												<th>IP Address</th>\
												<th>Action</th>\
											</tr>'+listing+'</table>';
							}
							$('#accounts-list').html(listing);
							// IPManager.Accounts.showPaging(cur_page);
					}					
			},
			
			wordwrap: function(str, repl, width, smart){
					if(str.length>width) {
							var dr = str.lastIndexOf('.');
							var myTmp = [];
							var cnt = 0;
							for(var i=0;i<str.length;i++){
									myTmp.push(str.charAt(i));
									cnt++;
									if(cnt==width) 
									{
											if(smart && dr>-1 && i>=dr) continue;
											myTmp.push(repl);
											cnt = 0;
									}
							}
							if(myTmp.length>0) str = myTmp.join('');
					}
					return str;
			},
			
			showPaging: function(cur_page){
					$('#accts-paging').remove();
					$('#accts-paging_cnt').remove();
					var items = (typeof IPManager.Accounts.search_items!=='undefined' && IPManager.Accounts.search_items.length>0) ? IPManager.Accounts.search_items : $('#accounts-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="accts-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.Accounts.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.Accounts.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="accts-paging">[<a href="javascript:void(0);" onclick="IPManager.Accounts.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#accounts-list').find('table').after(paging);
									}
							}
					}
			},
			
			search: function(){
					IPManager.Accounts.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.Accounts.search_kw)
					{
							var items = $('#accounts-list').data('items');
							IPManager.Accounts.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if(item.user.toLowerCase().indexOf(IPManager.Accounts.search_kw.toLowerCase())>-1 || item.domain.toLowerCase().indexOf(IPManager.Accounts.search_kw.toLowerCase())>-1 || item.ip.indexOf(IPManager.Accounts.search_kw)>-1)
											{
													IPManager.Accounts.search_items.push(item);
											}
									}
							}
							if(IPManager.Accounts.search_items.length==0) 	IPManager.Accounts.search_nflag = true;
							else 											IPManager.Accounts.search_nflag = false;
							IPManager.Accounts.displayItems(1);
					}
					else
					{
							IPManager.Accounts.search_nflag = false;
							IPManager.Accounts.search_items = [];
							IPManager.Accounts.displayItems(1);
					}
			},
			
			setIP: function(user, domain, ip, op, progress){
					if(!$("#progressbar").is(':visible')) 		$("#progressbar").show();
					if(!$("#progress-percent").is(':visible')) 	$("#progress-percent").show();
					
					if(op=='update_domain')
					{
							$("#progressbar").progressbar({value: progress});
							// $("#progress-percent").html('Updating <strong>'+domain+']</strong> data...');
							$("#progress-percent").html('Step 1/3: Processing...');
					}
					else if(op=='swaip')
					{
							$("#progressbar").progressbar({value: progress});
							// $("#progress-percent").html('Updating <strong>['+domain+']</strong> IP address...');
							$("#progress-percent").html('Step 2/3: Processing...');
					}
					else if(op=='rebuild_httpd_conf')
					{
							$("#progressbar").progressbar({value: progress});
							// $("#progress-percent").html('Rebuilding <strong>Apache</strong> configuration...');
							$("#progress-percent").html('Step 3/3: Processing...');
					}
					else if(op=='reboot_apache')
					{
							$("#progressbar").progressbar({value: progress});
							// $("#progress-percent").html('Restarting <strong>Apache</strong>...');
							$("#progress-percent").html('Step 4: Processing...');
					}
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op='+op+'&user='+user+'&domain='+domain+'&ip='+ip,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
										var _o = $.parseJSON(msg);
										var success = (typeof _o.ack!=='undefined' && _o.ack) ? true: false;
										if(!success)
										{
												$("#progress-percent").html('IP Changes for ['+domain+'] failed');
												setTimeout("$('#progressbar').progressbar({value: 0});$('#progressbar').hide();$('#progress-percent').hide();", 6000);
												
												jQuery.ajax({
														type: 	'GET',
														url: 	__base_url + 'ajax-admin.php?op=ip_change_failed&user='+user+'&domain='+domain+'&ip='+ip,
														cache: 	false,
														success: function(msg){
																// alert(msg);
														},
														error:function (xhr, ajaxOptions, thrownError){
																// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
														}
												});	
										}
										if(success && op=='update_domain')
										{
												$("#progressbar").progressbar({value: 33});
												 $("#progress-percent").html('Processing Request');
												//$("#progress-percent").html('Step 1/3: Done!');
												setTimeout("IPManager.Accounts.setIP('"+user+"', '"+domain+"', '"+ip+"', 'swaip', 33);", 2000);
										}
										else if(success && op=='swaip')
										{
												$("#progressbar").progressbar({value: 66});
												$("#progress-percent").html('Changing IP');
												//$("#progress-percent").html('Step 2/3: Done!');
												setTimeout("IPManager.Accounts.setIP('"+user+"', '"+domain+"', '"+ip+"', 'rebuild_httpd_conf', 66);", 2000);
										}
										else if(success && op=='rebuild_httpd_conf')
										{
												$("#progressbar").progressbar({value: 100});
												 $("#progress-percent").html('Done');
												$("#progress-percent").html('IP has been successfully changed!');
												setTimeout("$('#progressbar').progressbar({value: 0});$('#progressbar').hide();$('#progress-percent').html('<strong>"+ip+"</strong> is now associated to <strong>"+domain+"</strong>');", 3000);
												setTimeout("$('#progress-percent').html('');$('#progress-percent').hide();", 8000);
												
												IPManager.Accounts.getList(true, 1);
												
												jQuery.ajax({
														type: 	'GET',
														url: 	__base_url + 'ajax-admin.php?op=log_ip_change&user='+user+'&domain='+domain+'&ip='+ip,
														cache: 	false,
														success: function(msg){
																// alert(msg);
														},
														error:function (xhr, ajaxOptions, thrownError){
																// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
														}
												});	
										}
									} catch(err){
										alert(err.message);
									}
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			setIPOLD: function(user, domain, ip, op, progress){
					// $('#ip_change-confirm').remove();
					if(!$("#progressbar").is(':visible')) 		$("#progressbar").show();
					if(!$("#progress-percent").is(':visible')) 	$("#progress-percent").show();
					
					// if(typeof $('#ip_change-status')!=='object' || $('#ip_change-status').length==0)
					// {
							// $('#ip_change-status').remove();
							// $('#accounts-list').before('<div style="color:blue;margin-bottom:20px;text-align:center;font-weight:bold;" id="ip_change-status"></div>');
					// }
					if(op=='update_domain')
					{
							// $('#ip_change-status').html('Updating '+domain+' data...'+progress+'%');
							$("#progressbar").progressbar({value: progress});
							$("#progress-percent").html('Updating '+domain+' data...');
					}
					else if(op=='swaip')
					{
							// $('#ip_change-status').html('Updating '+domain+' IP address...'+progress+'%');
							$("#progressbar").progressbar({value: progress});
							$("#progress-percent").html('Updating '+domain+' IP address...');
					}
					else if(op=='rebuild_httpd_conf')
					{
							// $('#ip_change-status').html('Rebuilding httpd configuration...'+progress+'%');
							$("#progressbar").progressbar({value: progress});
							$("#progress-percent").html('Rebuilding httpd configuration...');
					}
					else if(op=='reboot_apache')
					{
							// $('#ip_change-status').html('Restarting Apache...'+progress+'%');
							$("#progressbar").progressbar({value: progress});
							$("#progress-percent").html('Restarting Apache...');
					}
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op='+op+'&user='+user+'&domain='+domain+'&ip='+ip,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
										var _o = $.parseJSON(msg);
										var success = (typeof _o.ack!=='undefined' && _o.ack) ? true: false;
										if(!success)
										{
												// $('#ip_change-status').html('IP Changes for ['+domain+'] failed');
												// setTimeout("$('#ip_change-status').remove();", 6000);
												$("#progress-percent").html('IP Changes for ['+domain+'] failed');
												setTimeout("$('#progressbar').progressbar({value: 0});$('#progressbar').hide();$('#progress-percent').hide();", 6000);
												
												jQuery.ajax({
														type: 	'GET',
														url: 	__base_url + 'ajax-admin.php?op=ip_change_failed&user='+user+'&domain='+domain+'&ip='+ip,
														cache: 	false,
														success: function(msg){
																// alert(msg);
														},
														error:function (xhr, ajaxOptions, thrownError){
																// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
														}
												});	
										}
										if(success && op=='update_domain')
										{
												// $('#ip_change-status').html(domain+' data updated...33%');
												$("#progressbar").progressbar({value: 33});
												$("#progress-percent").html(domain+' data updated...33%');
												setTimeout("IPManager.Accounts.setIP('"+user+"', '"+domain+"', '"+ip+"', 'swaip', '33');", 2000);
										}
										else if(success && op=='swaip')
										{
												$('#ip_change-status').html(domain+' IP address updated...66%');
												setTimeout("IPManager.Accounts.setIP('"+user+"', '"+domain+"', '"+ip+"', 'rebuild_httpd_conf', '66');", 2000);
										}
										else if(success && op=='rebuild_httpd_conf')
										{
												$('#ip_change-status').html('Httpd configuration rebuilt...100%');
												setTimeout("$('#ip_change-status').html('ip address for ["+domain+"] successfully set to ["+ip+"]');", 3000);
												setTimeout("$('#ip_change-status').remove();", 6000);
												IPManager.Accounts.getList(true);
												
												jQuery.ajax({
														type: 	'GET',
														url: 	__base_url + 'ajax-admin.php?op=log_ip_change&user='+user+'&domain='+domain+'&ip='+ip,
														cache: 	false,
														success: function(msg){
																// alert(msg);
														},
														error:function (xhr, ajaxOptions, thrownError){
																// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
														}
												});	
										}
										// else if(success && op=='rebuild_httpd_conf')
										// {
												// $('#ip_change-status').html('Httpd configuration rebuilt...75%');
												// setTimeout("IPManager.Accounts.setIP('"+user+"', '"+domain+"', '"+ip+"', 'reboot_apache', '75');", 2000);
										// }
										// else if(success && op=='reboot_apache')
										// {
												// $('#ip_change-status').html('Apache restarted...100%');
												// setTimeout("$('#ip_change-status').html('ip address for ["+domain+"] successfully set to ["+ip+"]');", 3000);
												// setTimeout("$('#ip_change-status').remove();", 6000);
												// IPManager.Accounts.getList(true);
												
												// jQuery.ajax({
														// type: 	'GET',
														// url: 	__base_url + 'ajax-admin.php?op=log_ip_change&user='+user+'&domain='+domain+'&ip='+ip,
														// cache: 	false,
														// success: function(msg){
																// alert(msg);
														// },
														// error:function (xhr, ajaxOptions, thrownError){
																// // alert('Error=' + thrownError + "\n\n" + xhr.responseText);
														// }
												// });	
										// }
									} catch(err){
										alert(err.message);
									}
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
	};
	
	IPManager.IP = {
			
			search_kw: '',
			search_items: [],
			search_nflag: false,
			
			popupList: function(user, domain, ip){
					$.fancybox({
							'width': '60%',
							'height': '95%',
							'autoScale': true,
							'transitionIn': 'fade',
							'transitionOut': 'fade',
							'type': 'iframe',
							'href': __base_url + 'popup_ips.php?user='+user+'&domain='+domain+'&ip='+ip
					});
			},
			
			getList: function(silent, cur_page){
					if(!silent) $('#ips-list').html('Loading ip addresses...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=ips_list',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													IPManager.IP.search_nflag = false;
													IPManager.IP.search_items = [];
													$('#ips-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#ips-list').data('items', queue);
													IPManager.IP.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});		
			},
			
			displayItems: function(cur_page){
					var items 	= (typeof IPManager.IP.search_items!=='undefined' && IPManager.IP.search_items.length>0) ? IPManager.IP.search_items : $('#ips-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.IP.search_nflag)
					{
							// if($('#search-container').length>0 && $('#ips-list').data('items').length==0) $('#search-container').remove();
							if($('#ips-list').data('items').length==0) $('#search-container').hide();
							$('#ips-list').html('<td colspan="2">No IP addresses found.</td>');
					}
					else
					{
							$('#search-container').show();
							var start 	= 0;
							var end 	= items.length;
							var listing = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											// listing = listing + '<tr>\
												// <td><a class=\'noudl\' href="javascript:void(0);" onclick="window.parent.quitIpsPopup(\''+default_user+'\',\''+default_domain+'\',\''+item.ip+'\');">'+item.ip+'</a></td>\
											// </tr>';
											listing = listing + '<li><a class=\'noudl\' href="javascript:void(0);" onclick="window.parent.quitIpsPopup(\''+default_user+'\',\''+default_domain+'\',\''+item.ip+'\');">'+item.ip+'</a></li>';
									}
							}
							if(listing!='')
							{
									/*var frm = '<table id="search-container" cellpadding="0" cellspacing="0" style="margin-left:auto;margin-right:auto;">\
												<tr>\
														<td><input type="text" name="q" value=""></td>\
														<td><input type="submit" name="bt-search" value="Find"></td>\
												</tr>\
										   </table>';*/
								/*
								var frm = '<div id="search-container" style="width:70%;margin-left:15%;margin-right:15%;"><form id="search-form" action="" method="post" onsubmit="IPManager.IP.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"></form>\
											<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.IP.search(); });</script></div>';*/
								// var js = '<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.IP.search(); });</script>';
								// if($('#search-container').length==0) $('#ips-list').before(frm);
								// listing = '<table cellspacing="0" cellpadding="0" style="margin-left:auto;margin-right:auto;">\
											// <tr>\
													// <th>IP Address</th>\
											// </tr>'+listing+'</table>';
								listing = '<td style="text-align:center;">\
												<h2>IP Address</h2>\
												<ul style="overflow-x:hidden;overflow-y:auto;height:265px;text-align:center;">\
													'+listing+'\
												</ul>\
											</td>\
											<td>&nbsp;</td>';
							}
							$('#ips-list').html(listing);
							// IPManager.IP.showPaging(cur_page);
					}	
			},
			
			showPaging: function(cur_page){
					$('#ips-paging').remove();
					$('#ips-paging_cnt').remove();
					var items 	= (typeof IPManager.IP.search_items!=='undefined' && IPManager.IP.search_items.length>0) ? IPManager.IP.search_items : $('#ips-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="ips-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.IP.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.IP.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="ips-paging">[<a href="javascript:void(0);" onclick="IPManager.IP.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#ips-list').find('table').after(paging);
									}
							}
					}
			},
	
			search: function(){
					IPManager.IP.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.IP.search_kw)
					{
							var items = $('#ips-list').data('items');
							IPManager.IP.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if(item.ip.indexOf(IPManager.IP.search_kw)>-1)
											{
													IPManager.IP.search_items.push(item);
											}
									}
							}
							if(IPManager.IP.search_items.length==0) IPManager.IP.search_nflag = true;
							else 									IPManager.IP.search_nflag = false;
							IPManager.IP.displayItems(1);
					}
					else
					{
							IPManager.IP.search_nflag = false;
							IPManager.IP.search_items = [];
							IPManager.IP.displayItems(1);
					}
			},
			
			getFreeDedicatedIPs: function(){
					// $('#ips-list').html('loading');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=get_free_dedicated_ips',
							cache: 	false,
							success: function(msg){
									alert(msg);
									// try {
											// var _o = $.parseJSON(msg);
											// if(typeof _o.items)
											// {
													// var listing = '';
													// if(_o.items.length>0)
													// {
															
															// $.each(_o.items, function(i, item){
																	// listing = listing + '<tr>\
																					// <td><input type="checkbox" id="item-'+(item.replace(/\./g,''))+'" value="'+reseller+'|'+item+'" /></td>\
																					// <td><label for="item-'+(item.replace(/\./g,''))+'">'+item+'</label></td>\
																			   // </tr>';
															// });
													// }
													// if(listing!='')
													// {
															// listing =  '<tr>\
																				// <th>&nbsp;</th>\
																				// <th>IP Address</th>\
																		// </tr>' + listing + '<tr>\
																				// <td colspan="2" style="text-align:center;"><input type="submit" name="bt-unassign" value="Un-Assign Selected" /></td>\
																		// </tr>';
															// var js = '<script language="javascript">\
																	// $("#unassign-form").bind("submit", function(){\
																			// var reseller = \'\';\
																			// var ips 	 = \'\';\
																			// $(\'#unassign-form input[type="checkbox"]:checked\').each(function(i){ \
																					// var p = $(this).val().split(\'|\');\
																					// if(typeof p[0]!==\'undefined\' && reseller==\'\') reseller = p[0];\
																					// ip = (typeof p[1]!==\'undefined\') ? p[1] : \'\';\
																					// if(ip) ips = ips + (ips?\',\':\'\') + ip;\
																			// });\
																			// if(reseller && ips) IPManager.Resellers.unassignIP(reseller, ips);\
																			// return false;\
																	// });\
															// </script>';
															// $('#ips-list').html('<div class="recent"><h1>IP addresses assigned to ['+reseller+']</h1></div><form id="unassign-form" method="post" action=""><table cellpadding="0" cellspacing="0">'+listing+'</table></form>' + js);
													// }
													// else
													// {
															// $('#ips-list').html('No ip addresses found.');
													// }
											// }
									// } catch (err){
											// alert(err.message);
									// }
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
	};
	
	IPManager.IpPool = {
			
			search_kw: '',
			search_items: [],
			search_nflag: false,
			search_cur_page: 1,
			filter_on: false,
			
			getList: function(silent, cur_page){
					if(!silent) $('#ips-list').html('Loading ip addresses...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=ips_pool',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													if(typeof _o.items=='boolean' && !_o.items)
													{
															$('#ips-list').html('An error occurred. <a href="javascript:void(0);" onclick="IPManager.IpPool.getList('+silent+', '+cur_page+');">Reload</a>');
															return false;
													}
													IPManager.IpPool.search_nflag = false;
													IPManager.IpPool.search_items = [];
													$('#ips-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#ips-list').data('items', queue);
													IPManager.IpPool.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
									$('#ips-list').html("<span style='color:red;'>An unexpected error occurred while loading list. Please <a href='javascript:void(0);' onclick='location.reload();'>reload</a></span>");
							}
					});		
			},
			
			displayItems: function(cur_page){
					var items 	= (typeof IPManager.IpPool.search_items!=='undefined' && IPManager.IpPool.search_items.length>0) ? IPManager.IpPool.search_items : $('#ips-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.IpPool.search_nflag)
					{
							if($('#search-container').length>0 && $('#ips-list').data('items').length==0) $('#search-container').remove();
							listing = '<table cellspacing="0" cellpadding="0"><tr><td>No IP addresses found.</td></tr></table>';
							$('#ips-list').html(listing);
					}
					else
					{
							IPManager.IpPool.search_cur_page = cur_page;
							var start 	= 0;
							var end 	= items.length;
							var listing = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											listing = listing + '<tr id="item-'+item.ip.replace(/\./g, '_')+'">\
												<td style="text-align:left;">'+item.ip+'</td>\
												<td style="text-align:right;">'+(item.ipm_dedicated?'yes':'no')+'</td>\
												<td style="text-align:right;">'+item.usage_count+'</td>\
												<td style="text-align:right;">\
													<a style="'+(!item.ipm_dedicated?'display:none':'')+'" href="javascript:void(0);" onclick="IPManager.IpPool.changeStatus(\'shared\',\''+item.ip+'\');">shared</a>\
													<a style="'+(item.ipm_dedicated?'display:none':'')+'" href="javascript:void(0);" onclick="IPManager.IpPool.changeStatus(\'dedicated\',\''+item.ip+'\');">dedicated</a>\
											</tr>';
									}
							}
							if(listing!='')
							{
								var frm = '<div id="search-container"><form id="search-form" action="" method="post" onsubmit="IPManager.IpPool.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"><br><br>\
											<fieldset>\
											<legend>Filter</legend>\
											<table cellpadding="" cellspacing="0">\
											<tr style="border-bottom:1px solid grey;">\
												<td>Type:</td>\
												<td><input type="radio" name="filter_type" value="shared"> shared</td>\
												<td><input type="radio" name="filter_type" value="dedicated"> dedicated</td>\
												<td><input type="radio" name="filter_type" value="both" checked> both</td>\
											</tr>\
											<tr>\
												<td>In use:</td>\
												<td><input type="radio" name="filter_usage" value="yes"> yes</td>\
												<td><input type="radio" name="filter_usage" value="no"> no</td>\
												<td><input type="radio" name="filter_usage" value="both" checked> both</td>\
											</tr>\
											</table>\
											</fieldset>\
											<br><br>\
											</form>\
											<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.IpPool.search(); }); \
											$(\'input[name="filter_type"],input[name="filter_usage"]\').bind(\'click\', function(){ IPManager.IpPool.filterResults(); });\
											</script></div>';
								if($('#search-container').length==0) $('#ips-list').before(frm);
								listing = '<table cellspacing="0" cellpadding="0">\
											<tr>\
													<th>IP Address</th>\
													<th>Dedicated?</th>\
													<th>Websites</th>\
													<th>Change to</th>\
											</tr>'+listing+'</table>';
							}
							$('#ips-list').html(listing);
							// IPManager.IpPool.showPaging(cur_page);
					}	
			},
			
			changeStatus: function(status, ip){
					var sl = ip.replace(/\./g, '_');
					$('.cs-status').remove();
					// $('#item-'+sl).find('td:eq(3)').find('a:eq(1)').after(' <span class="cs-status">...</span>');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=change_ip_status&ip='+ip+'&status='+status,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.error!=='undefined')
											{
													alert(_o.error);
											}
											else if(typeof _o.success!=='undefined')
											{
													if($('#item-'+sl).find('td:eq(1)').html()=='yes') $('#item-'+sl).find('td:eq(1)').html('no');
													else if($('#item-'+sl).find('td:eq(1)').html()=='no') $('#item-'+sl).find('td:eq(1)').html('yes');
													$('#item-'+sl).find('td:eq(3)').find('a:eq(0)').toggle();
													$('#item-'+sl).find('td:eq(3)').find('a:eq(1)').toggle();
													
													var items = $('#ips-list').data('items');
													for(var i=0;i<items.length;i++){
															var item = items[i];
															if(item.ip==ip)
															{
																	items[i].ipm_dedicated = items[i].ipm_dedicated ? false : true;
															}
													}
													$('#ips-list').data('items', items);
											}
									} catch(err){
											alert(err.message);
									}
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			filterResults: function(){
					IPManager.IpPool.filter_on = true;
					IPManager.IpPool.search();
			},
			
			showPaging: function(cur_page){
					$('#ips-paging').remove();
					$('#ips-paging_cnt').remove();
					var items 	= (typeof IPManager.IpPool.search_items!=='undefined' && IPManager.IpPool.search_items.length>0) ? IPManager.IpPool.search_items : $('#ips-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="ips-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.IpPool.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.IpPool.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="ips-paging">[<a href="javascript:void(0);" onclick="IPManager.IpPool.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#ips-list').find('table').after(paging);
									}
							}
					}
			},
	
			search: function(){
					IPManager.IpPool.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.IpPool.search_kw || IPManager.IpPool.filter_on)
					{
							IPManager.IpPool.filter_on = false;
							var items = $('#ips-list').data('items');
							IPManager.IpPool.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if($('input[name="filter_type"]:checked').val()=='shared' && item.ipm_dedicated) 			continue;
											else if($('input[name="filter_type"]:checked').val()=='dedicated' && !item.ipm_dedicated) 	continue;
											if($('input[name="filter_usage"]:checked').val()=='yes' && item.usage_count==0) 			continue;
											else if($('input[name="filter_usage"]:checked').val()=='no' && item.usage_count>0) 			continue;
											
											if(item.ip.indexOf(IPManager.IpPool.search_kw)>-1)
											{
													IPManager.IpPool.search_items.push(item);
											}
									}
							}
							if(IPManager.IpPool.search_items.length==0) IPManager.IpPool.search_nflag = true;
							else 									IPManager.IpPool.search_nflag = false;
							IPManager.IpPool.displayItems(1);
					}
					else
					{
							IPManager.IpPool.search_nflag = false;
							IPManager.IpPool.search_items = [];
							IPManager.IpPool.displayItems(1);
					}
			},
	
	};
	
	IPManager.Resellers = {
			
			search_kw: '',
			search_items: [],
			search_nflag: false,
			
			getResellersList: function(silent, cur_page){
					if(!silent) $('#resellers-list').html('Loading resellers...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=resellers_list',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													IPManager.Resellers.search_nflag = false;
													IPManager.Resellers.search_items = [];
													$('#resellers-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#resellers-list').data('items', queue);
													IPManager.Resellers.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
					
			},
			
			displayItems: function(cur_page){					
					var items = (typeof IPManager.Resellers.search_items!=='undefined' && IPManager.Resellers.search_items.length>0) ? IPManager.Resellers.search_items : $('#resellers-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.Resellers.search_nflag)
					{
							if($('#search-container').length>0 && $('#resellers-list').data('items').length==0) $('#search-container').remove();
							listing = '<table cellspacing="0" cellpadding="0"><tr><td>No resellers found.</td></tr></table>';
							$('#resellers-list').html(listing);
					}
					else
					{
							var start 	= 0;
							var end 	= items.length;
							var listing = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var reseller_name = items[i];
											listing = listing + '<li class="listing-row">\
												<span><a title="View shared ips assigned to '+reseller_name+'" href="javascript:void(0);\" onclick="IPManager.Resellers.getSharedIPs(\''+reseller_name+'\');">'+reseller_name+'</a></span>\
												<span class="last"><a title="Assign new ip to '+reseller_name+'" href="javascript:void(0);\" onclick="IPManager.Resellers.popupList(\''+reseller_name+'\');">assign IP</a></span>\
											</li>';
									}
							}
							if(listing!='')
							{
								var frm = '<div id="search-container" style="margin-bottom:15px;margin-top:25px;"><fieldset><legend>Search</legend><form id="search-form" autocomplete="off" action="" method="post" onsubmit="IPManager.Resellers.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"></form></fieldset>\
											<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.Resellers.search(); });</script></div>';
								if($('#search-container').length==0) $('#resellers-list').before(frm);
								listing = '<ul class="listing">\
												<li class="listing-row head">\
													<span class="last">Reseller</span>\
													<span>Action</span>\
												</li>\
											</ul>\
											<ul class="listing mediumH">\
												'+listing+'\
											</ul>';
							}
							$('#resellers-list').html(listing);
							// IPManager.Resellers.showPaging(cur_page);
					}					
			},
			
			showPaging: function(cur_page){
					$('#accts-paging').remove();
					$('#accts-paging_cnt').remove();
					var items = (typeof IPManager.Resellers.search_items!=='undefined' && IPManager.Resellers.search_items.length>0) ? IPManager.Resellers.search_items : $('#resellers-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="accts-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.Resellers.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.Resellers.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="accts-paging">[<a href="javascript:void(0);" onclick="IPManager.Resellers.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#resellers-list').find('table').after(paging);
									}
							}
					}
			},
			
			search: function(){
					IPManager.Resellers.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.Resellers.search_kw)
					{
							var items = $('#resellers-list').data('items');
							IPManager.Resellers.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if(item.toLowerCase().indexOf(IPManager.Resellers.search_kw.toLowerCase())>-1)
											{
													IPManager.Resellers.search_items.push(item);
											}
									}
							}
							if(IPManager.Resellers.search_items.length==0) 	IPManager.Resellers.search_nflag = true;
							else 											IPManager.Resellers.search_nflag = false;
							IPManager.Resellers.displayItems(1);
					}
					else
					{
							IPManager.Resellers.search_nflag = false;
							IPManager.Resellers.search_items = [];
							IPManager.Resellers.displayItems(1);
					}
			},
			
			popupList: function(reseller){
					$.fancybox({
							'width': '60%',
							'height': '95%',
							'autoScale': true,
							'transitionIn': 'fade',
							'transitionOut': 'fade',
							'type': 'iframe',
							'href': __base_url + 'popup_reseller_ips.php?reseller='+reseller,
					});
			},
			
			assignIP: function(reseller, ip){
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=assign_reseller_ip&ip='+ip+'&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									if($('#ip_assign-confirm').length>0) $('#ip_assign-confirm').remove();
									var cur = window.location.href;
									if(cur.indexOf('resellers_dedicated_ips.php')>-1) 	IPManager.ResellersDIPs.getDedicatedIPs(reseller);
									else												IPManager.Resellers.getSharedIPs(reseller);
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			unassignIP: function(reseller, ip){
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=unassign_reseller_ip&ip='+ip+'&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									IPManager.Resellers.getSharedIPs(reseller);												
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			getSharedIPs: function(reseller){
					$('#ips-list').html('loading');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=get_reseller_shared_ip&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.items)
											{
													var listing = '';
													if(_o.items.length>0)
													{
															
															$.each(_o.items, function(i, item){
																	listing = listing + '<tr>\
																					<td><input type="checkbox" id="item-'+(item.replace(/\./g,''))+'" value="'+reseller+'|'+item+'" /></td>\
																					<td><label for="item-'+(item.replace(/\./g,''))+'">'+item+'</label></td>\
																			   </tr>';
															});
													}
													if(listing!='')
													{
															listing =  '<tr>\
																				<th><input type="checkbox" name="select-all" class="batch-select" value="" />&nbsp;</th>\
																				<th>IP Address</th>\
																		</tr>' + listing + '<tr>\
																				<td colspan="2" style="text-align:center;"><input type="submit" name="bt-unassign" value="Un-Assign Selected" /></td>\
																		</tr>';
															/*
															var js = '<script language="javascript">\
																	$("#unassign-form").bind("submit", function(){\
																			$("#unassign-form input[name=checkbox]:checked").each(function(i, val){\
																					alert(val);\
																			});\
																			// IPManager.Resellers.getSharedIPs(reseller);\
																			return false;\
																	});\
															</script>';alert($(this).val());\
															*/
															var js = '<script language="javascript">\
																	$("#unassign-form").bind("submit", function(){\
																			var reseller = \'\';\
																			var ips 	 = \'\';\
																			$(\'#unassign-form input[type="checkbox"]:checked\').each(function(i){ \
																					var p = $(this).val().split(\'|\');\
																					if(typeof p[0]!==\'undefined\' && reseller==\'\') reseller = p[0];\
																					ip = (typeof p[1]!==\'undefined\') ? p[1] : \'\';\
																					if(ip) ips = ips + (ips?\',\':\'\') + ip;\
																			});\
																			if(reseller && ips) IPManager.Resellers.unassignIP(reseller, ips);\
																			return false;\
																	});\
																	$("input.batch-select").bind("click", function(){\
																			if($(this).is(":checked"))\
																			{\
																					$(\'#unassign-form input[type="checkbox"]:not(:checked)\').each(function(i){ \
																								$(this).attr("checked", true);\
																					});\
																			}\
																			else\
																			{\
																					$(\'#unassign-form input[type="checkbox"]:checked\').each(function(i){ \
																								$(this).attr("checked", false);\
																					});\
																			}\
																	});\
															</script>';
															$('#ips-list').html('<div class="recent"><h1>IP addresses assigned to ['+reseller+']</h1></div><form id="unassign-form" method="post" action=""><table cellpadding="0" cellspacing="0">'+listing+'</table></form>' + js);
													}
													else
													{
															$('#ips-list').html('No ip addresses found.');
													}
											}
									} catch (err){
											alert(err.message);
											alert(msg);
									}
									// if($('ip_assign-confirm').length>0) $('ip_assign-confirm').remove();
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
	};
	
	IPManager.ResellersDIPs = {
			
			search_kw: '',
			search_items: [],
			search_nflag: false,
			
			getList: function(silent, cur_page){
					if(!silent) $('#resellers-list').html('Loading resellers...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=resellers_list',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													IPManager.ResellersDIPs.search_nflag = false;
													IPManager.ResellersDIPs.search_items = [];
													$('#resellers-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#resellers-list').data('items', queue);
													IPManager.ResellersDIPs.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
					
			},
			
			displayItems: function(cur_page){					
					var items = (typeof IPManager.ResellersDIPs.search_items!=='undefined' && IPManager.ResellersDIPs.search_items.length>0) ? IPManager.ResellersDIPs.search_items : $('#resellers-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.ResellersDIPs.search_nflag)
					{
							if($('#search-container').length>0 && $('#resellers-list').data('items').length==0) $('#search-container').remove();
							listing = '<table cellspacing="0" cellpadding="0"><tr><td>No resellers found.</td></tr></table>';
							$('#resellers-list').html(listing);
					}
					else
					{
							var start 	= 0;
							var end 	= items.length;
							var listing = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var reseller_name = items[i];
											listing = listing + '<li class="listing-row">\
												<span><a title="View dedicated ips assigned to '+reseller_name+'" href="javascript:void(0);\" onclick="IPManager.ResellersDIPs.getDedicatedIPs(\''+reseller_name+'\');">'+reseller_name+'</a></span>\
												<span class="last"><a title="Assign dedicated ip to '+reseller_name+'" href="javascript:void(0);\" onclick="IPManager.ResellersDIPs.popupList(\''+reseller_name+'\');">assign IP</a></span>\
											</li>';
									}
							}
							if(listing!='')
							{
								var frm = '<div id="search-container"><form id="search-form" action="" method="post" onsubmit="IPManager.ResellersDIPs.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"></form>\
											<script language="javascript">$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ IPManager.ResellersDIPs.search(); });</script></div>';
								if($('#search-container').length==0) $('#resellers-list').before(frm);
								listing = '<ul class="listing">\
												<li class="listing-row head">\
													<span class="last">Reseller</span>\
													<span>Action</span>\
												</li>\
											</ul>\
											<ul class="listing mediumH">\
												'+listing+'\
											</ul>';
							}
							$('#resellers-list').html(listing);
							// IPManager.ResellersDIPs.showPaging(cur_page);
					}					
			},
			
			showPaging: function(cur_page){
					$('#accts-paging').remove();
					$('#accts-paging_cnt').remove();
					var items = (typeof IPManager.ResellersDIPs.search_items!=='undefined' && IPManager.ResellersDIPs.search_items.length>0) ? IPManager.ResellersDIPs.search_items : $('#resellers-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="accts-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.ResellersDIPs.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.ResellersDIPs.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="accts-paging">[<a href="javascript:void(0);" onclick="IPManager.ResellersDIPs.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#resellers-list').find('table').after(paging);
									}
							}
					}
			},
			
			search: function(){
					IPManager.ResellersDIPs.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.ResellersDIPs.search_kw)
					{
							var items = $('#resellers-list').data('items');
							IPManager.ResellersDIPs.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if(item.toLowerCase().indexOf(IPManager.ResellersDIPs.search_kw.toLowerCase())>-1)
											{
													IPManager.ResellersDIPs.search_items.push(item);
											}
									}
							}
							if(IPManager.ResellersDIPs.search_items.length==0) 	IPManager.ResellersDIPs.search_nflag = true;
							else 											IPManager.ResellersDIPs.search_nflag = false;
							IPManager.ResellersDIPs.displayItems(1);
					}
					else
					{
							IPManager.ResellersDIPs.search_nflag = false;
							IPManager.ResellersDIPs.search_items = [];
							IPManager.ResellersDIPs.displayItems(1);
					}
			},
			
			popupList: function(reseller){
					$.fancybox({
							'width': '65%',
							'height': '95%',
							'autoScale': true,
							'transitionIn': 'fade',
							'transitionOut': 'fade',
							'type': 'iframe',
							'href': __base_url + 'popup_free_dedicated_ips.php?reseller='+reseller,
					});
			},
			
			assignIP: function(reseller, ip){
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=assign_reseller_ip&ip='+ip+'&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									if($('#ip_assign-confirm').length>0) $('#ip_assign-confirm').remove();
									IPManager.ResellersDIPs.getSharedIPs(reseller);
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			unassignIP: function(reseller, ip){
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=unassign_reseller_ip&ip='+ip+'&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									IPManager.ResellersDIPs.getDedicatedIPs(reseller);
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
			
			getDedicatedIPs: function(reseller){
					$('#ips-list').html('loading');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=get_reseller_dedicated_ip&reseller='+reseller,
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.items)
											{
													var listing = '';
													if(_o.items.length>0)
													{
															
															$.each(_o.items, function(i, item){
																	listing = listing + '<tr>\
																					<td><input type="checkbox" id="item-'+(item.replace(/\./g,''))+'" value="'+reseller+'|'+item+'" /></td>\
																					<td><label for="item-'+(item.replace(/\./g,''))+'">'+item+'</label></td>\
																			   </tr>';
															});
													}
													if(listing!='')
													{
															listing =  '<tr>\
																				<th><input type="checkbox" name="select-all" class="batch-select" value="" />&nbsp;</th>\
																				<th>IP Address</th>\
																		</tr>' + listing + '<tr>\
																				<td colspan="2" style="text-align:center;"><input type="submit" name="bt-unassign" value="Un-Assign Selected" /></td>\
																		</tr>';
															/*
															var js = '<script language="javascript">\
																	$("#unassign-form").bind("submit", function(){\
																			$("#unassign-form input[name=checkbox]:checked").each(function(i, val){\
																					alert(val);\
																			});\
																			// IPManager.ResellersDIPs.getSharedIPs(reseller);\
																			return false;\
																	});\
															</script>';alert($(this).val());\
															*/
															var js = '<script language="javascript">\
																	$("#unassign-form").bind("submit", function(){\
																			var reseller = \'\';\
																			var ips 	 = \'\';\
																			$(\'#unassign-form input[type="checkbox"]:checked\').each(function(i){ \
																					var p = $(this).val().split(\'|\');\
																					if(typeof p[0]!==\'undefined\' && reseller==\'\') reseller = p[0];\
																					ip = (typeof p[1]!==\'undefined\') ? p[1] : \'\';\
																					if(ip) ips = ips + (ips?\',\':\'\') + ip;\
																			});\
																			if(reseller && ips) IPManager.ResellersDIPs.unassignIP(reseller, ips);\
																			return false;\
																	});\
																	$("input.batch-select").bind("click", function(){\
																			if($(this).is(":checked"))\
																			{\
																					$(\'#unassign-form input[type="checkbox"]:not(:checked)\').each(function(i){ \
																								$(this).attr("checked", true);\
																					});\
																			}\
																			else\
																			{\
																					$(\'#unassign-form input[type="checkbox"]:checked\').each(function(i){ \
																								$(this).attr("checked", false);\
																					});\
																			}\
																	});\
															</script>';
															$('#ips-list').html('<div class="recent"><h1>IP addresses assigned to ['+reseller+']</h1></div><form id="unassign-form" method="post" action=""><table cellpadding="0" cellspacing="0">'+listing+'</table></form>' + js);
													}
													else
													{
															$('#ips-list').html('No ip addresses found.');
													}
											}
									} catch (err){
											alert(err.message);
									}
									// if($('ip_assign-confirm').length>0) $('ip_assign-confirm').remove();
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});	
			},
	};
	
	IPManager.ResellersIpPool = {
			search_kw: '',
			search_items: [],
			search_nflag: false,
			ip_stat: '',
			
			getList: function(silent, cur_page){
					IPManager.ResellersIpPool.ip_stat = 'shared';
					if(!silent) $('#ips-list').html('Loading ip addresses...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=resellers_ips_pool&type=shared',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													IPManager.ResellersIpPool.search_nflag = false;
													IPManager.ResellersIpPool.search_items = [];
													$('#ips-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#ips-list').data('items', queue);
													IPManager.ResellersIpPool.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});		
			},
			
			getDedicatedList: function(silent, cur_page){
					IPManager.ResellersIpPool.ip_stat = 'dedicated';
					if(!silent) $('#ips-list').html('Loading ip addresses...');
					jQuery.ajax({
							type: 	'GET',
							url: 	__base_url + 'ajax-admin.php?op=resellers_ips_pool&type=dedicated',
							cache: 	false,
							success: function(msg){
									// alert(msg);
									try {
											var _o = $.parseJSON(msg);
											if(typeof _o.success!=='undefined' && typeof _o.items!=='undefined')
											{
													IPManager.ResellersIpPool.search_nflag = false;
													IPManager.ResellersIpPool.search_items = [];
													$('#ips-list').data('updated', new Date().getTime());
													var queue = [];
													$.each(_o.items, function(indx, item){ queue.push(item); });
													$('#ips-list').data('items', queue);
													IPManager.ResellersIpPool.displayItems(cur_page);													
											}
									} catch(err){
											alert(err.message);
									}	
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert('Error=' + thrownError + "\n\n" + xhr.responseText);
							}
					});		
			},
			
			displayItems: function(cur_page){
					var items 	= (typeof IPManager.ResellersIpPool.search_items!=='undefined' && IPManager.ResellersIpPool.search_items.length>0) ? IPManager.ResellersIpPool.search_items : $('#ips-list').data('items');
					if(typeof items=='undefined' || items.length==0 || IPManager.ResellersIpPool.search_nflag)
					{
							var msg = '';
							if(IPManager.ResellersIpPool.ip_stat=='dedicated') 	msg = 'No IP addresses found.';
							else 												msg = 'No IP addresses found.';
							if($('#search-container').length>0 && $('#ips-list').data('items').length==0) $('#search-container').remove();
							listing = '<table cellspacing="0" cellpadding="0"><tr><td>No IP addresses found.</td></tr></table>';
							$('#ips-list').html(listing);
					}
					else
					{
							var start 	= 0;
							var end 	= items.length;
							var listing = '';
							for(var i=start;i<end;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											listing = listing + '<tr>\
												<td><input class=tickable type="checkbox" id="ip-'+(item.ip.replace(/\./g, ''))+'" value="'+default_reseller+'|'+item.ip+'"></td>\
												<td><label  for="ip-'+(item.ip.replace(/\./g, ''))+'">'+item.ip+'</label></td>\
												<td>&nbsp</td>\
											</tr>';
									}
							}
							if(listing!='')
							{
								var frm = '<div id="search-container" style="width:70%;margin-left:15%;margin-right:15%;"><form id="search-form" action="" method="post" onsubmit="IPManager.ResellersIpPool.search();return false;"><input type="text" name="q" value=""><input type="submit" name="bt-search" value="Find"></form>\
											<script language="javascript">\
													$(\'#search-form\').find(\'input[name="q"]\').bind(\'keyup\', function(){ \
															IPManager.ResellersIpPool.search(); \
													});\
											</script>\
											</div>';
								if($('#search-container').length==0) $('#ips-list').before(frm);
								listing = '<form id="ips-pool" action="" method="post">\
											<table cellspacing="0" cellpadding="0" style="margin-left:auto;margin-right:auto;">\
											<tr>\
													<th><input type="checkbox" id="toggle-all" name="toggle-all" value=""></th>\
													<th>Ip Address</th>\
													<th><input type=button id="bt-apply" value="Apply Now!" onclick="window.parent.applyAssignments();"></th>\
											</tr>'+listing+'</table></form>\
											<script language="javascript">;\
												$(\'#ips-pool input.tickable[type="checkbox"]\').bind(\'change\', function(){ ;\
														if($(\'#ips-pool input[name="toggle-all"]\').is(\':checked\')) $(\'#ips-pool input[name="toggle-all"]\').removeAttr(\'checked\'); \
														var p = $(this).val().split(\'|\'); \
														var reseller = (typeof p[0]!=="undefined") ? p[0] : ""; \
														var ip = (typeof p[1]!=="undefined") ? p[1] : ""; \
														if(reseller && ip) { \
																if($(this).is(\':checked\')) window.parent.addIP(reseller, ip); \
																else window.parent.removeIP(reseller, ip);\
														} \
												});\
												$(\'#ips-pool\').find(\'input[name="toggle-all"]\').bind(\'click\', function(){ \
														if($(this).is(\':checked\')) { \
																$(\'#ips-pool input[type="checkbox"]\').each(function(){ \
																		if(!$(this).is(\':checked\')) { \
																			$(this).attr(\'checked\', \'checked\');\
																			var p = $(this).val().split(\'|\'); \
																			var reseller = (typeof p[0]!=="undefined") ? p[0] : ""; \
																			var ip = (typeof p[1]!=="undefined") ? p[1] : ""; \
																			if(reseller && ip) window.parent.addIP(reseller, ip); \
																		}\
																});\
														} else { \
																$(\'#ips-pool input[type="checkbox"]\').each(function(){ \
																		if($(this).is(\':checked\')) $(this).removeAttr(\'checked\');\
																		var p = $(this).val().split(\'|\'); \
																		var reseller = (typeof p[0]!=="undefined") ? p[0] : ""; \
																		var ip = (typeof p[1]!=="undefined") ? p[1] : ""; \
																		if(reseller && ip) window.parent.removeIP(reseller, ip); \
																});\
														}\
												});\
											</script>';
							}
							$('#ips-list').html(listing);
							// IPManager.ResellersIpPool.showPaging(cur_page);
					}	
			},
			
			showPaging: function(cur_page){
					$('#ips-paging').remove();
					$('#ips-paging_cnt').remove();
					var items 	= (typeof IPManager.ResellersIpPool.search_items!=='undefined' && IPManager.ResellersIpPool.search_items.length>0) ? IPManager.ResellersIpPool.search_items : $('#ips-list').data('items');
					if(typeof items!=='undefined')
					{
							if(items.length>0)
							{
									var cnt		  	= 0;
									var max_links 	= 10;
									var per_page 	= 10;
									var max_page 	= Math.ceil(items.length/per_page);
									if(max_page>1)
									{
											var start	 	= cur_page-4;
											if(start<=0) 	start = 1;
											var end	 	 	= cur_page+4;
											if(end>max_page) 	end = max_page;
											var paging 	 = '';
											paging = paging + '<p id="ips-paging_cnt">Page '+cur_page+' of '+max_page+'</p>';
											if(cur_page-1>=1) paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.ResellersIpPool.displayItems('+(cur_page-1)+');">Prev</a>]';											
											for(var i=start;i<=end;i++)
											{
													if(i==cur_page)
													{
															paging = paging + '['+i+']';
													}
													else
													{
															paging = paging + '[<a href="javascript:void(0);" onclick="IPManager.ResellersIpPool.displayItems('+i+');">'+i+'</a>]';
													}
													cnt++;
													if(cnt>=max_links) break;
											}
											if(cur_page+1<=max_page) paging = paging + '<span id="ips-paging">[<a href="javascript:void(0);" onclick="IPManager.ResellersIpPool.displayItems('+(cur_page+1)+');">Next</a>]</span>';
											$('#ips-list').find('table').after(paging);
									}
							}
					}
			},
	
			search: function(){
					IPManager.ResellersIpPool.search_kw = $('#search-form').find('input[name="q"]').val();
					if(IPManager.ResellersIpPool.search_kw)
					{
							var items = $('#ips-list').data('items');
							IPManager.ResellersIpPool.search_items = [];
							for(var i=0;i<items.length;i++)
							{
									if(typeof items[i]!=='undefined')
									{
											var item = items[i];
											if(item.ip.indexOf(IPManager.ResellersIpPool.search_kw)>-1)
											{
													IPManager.ResellersIpPool.search_items.push(item);
											}
									}
							}
							if(IPManager.ResellersIpPool.search_items.length==0) IPManager.ResellersIpPool.search_nflag = true;
							else 									IPManager.ResellersIpPool.search_nflag = false;
							IPManager.ResellersIpPool.displayItems(1);
					}
					else
					{
							IPManager.ResellersIpPool.search_nflag = false;
							IPManager.ResellersIpPool.search_items = [];
							IPManager.ResellersIpPool.displayItems(1);
					}
			},
	};
	
	
	