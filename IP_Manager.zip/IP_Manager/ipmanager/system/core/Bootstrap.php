<?php  if ( ! defined('BASE_PATH')) exit('No direct script access allowed');
		define('LOG_THRESHOLD', 4);
		define('WHM_TOKEN', $_ENV['cp_security_token']);
		define('PROTO', 'http'.($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS'])!='off'?'s':''));
		define('SERVER_ADDR', ($_SERVER['SERVER_ADDR']!=$_SERVER['HTTP_HOST']?$_SERVER['HTTP_HOST']:$_SERVER['SERVER_ADDR']));
		define('SERVER_PORT', ($_SERVER['SERVER_PORT']!=2086?$_SERVER['SERVER_PORT']:2086));
		define('BASE_URL', PROTO . '://' . SERVER_ADDR . ':' . SERVER_PORT);
		define('CUR_USER', $_ENV['REMOTE_USER']);
		define('API_BASE_URL', 'http://127.0.0.1:2086/');
		
		require_once(BASE_PATH . 'system/core/Common.php');	
		
		define('IS_ADMIN', is_access_allowed(CUR_USER, 'all') ? TRUE : FALSE);
		
		if(whm_get_reseller_php_status()=='OFF') whm_enable_reseller_php();
		
		define('PHP_RS', whm_get_reseller_php_status());
		
/* End of file Bootstrap.php */
/* Location: ./system/core/Bootstrap.php */
