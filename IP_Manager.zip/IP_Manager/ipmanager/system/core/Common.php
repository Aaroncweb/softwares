<?php  if ( ! defined('BASE_PATH')) exit('No direct script access allowed');

	function is_access_allowed($user, $acl) {
			//return FALSE;
			if ($user == "root") {
				return TRUE;
			}
			return false;
			$reseller = file_get_contents("/var/cpanel/resellers");
			foreach ( split( "\n", $reseller ) as $line ) {
				if ( preg_match( "/^$user:/", $line) ) {
					$line = preg_replace( "/^$user:/", "", $line);
					foreach ( split(",", $line )  as $perm ) {
						if ( $perm == "all" || $perm == $acl ) {
							return TRUE;
						}
					}
				}
			}
			return 0;
	}
	
	function whm_get_access_hash($user='root'){
			$sui = posix_getpwnam($user);
			if($sui === FALSE) {
					log_message('error', "'whm_get_access_hash()' Failed to get system user information for username $user");
					return FALSE;
			}
			if(!is_file($sui['dir']."/.accesshash")) 
			{
					ob_start();
					@system("/usr/local/cpanel/whostmgr/bin/whostmgr setrhash");
					ob_end_clean();
			}
			$accessHash = @file_get_contents($sui['dir']."/.accesshash");
			if($accessHash === FALSE) {
					log_message('error', "'whm_get_access_hash()' Failed to get access hash for user $user");
					return FALSE;
			}
			$accessHash = preg_replace("/(\n|\r|\s)/", '', $accessHash);
			return $accessHash;
	}
	
	function whm_get_accts($user='root'){
			$accessHash = whm_get_access_hash();
			if($accessHash === FALSE) 
			{
					log_message('error', "'whm_get_accts()' no access hash available");
					return FALSE;
			}
			$context = stream_context_create( 
				array( 
					'http' => array(
						'method' => 'POST',
						'header' => "Authorization: WHM $user:".$accessHash."\r\n" 
					) 
				)
			);
			$json = file_get_contents(API_BASE_URL . 'json-api/listaccts', false, $context);
			
			if($json === '') {
					log_message('error', "'whm_get_accts()' server returned nothing");
					return FALSE;
			}
			if($json === FALSE) {
					log_message('error', "'whm_get_accts()' failed getting accounts list");
					return FALSE;
			}
			$json = utf8_encode($json);
			$items = json_decode($json, TRUE);
			if(is_array($items) === FALSE) {
					log_message('error', "'whm_get_accts()' failed decoding json response to 'listaccts'. JSON: $json");
					return FALSE;
			}
						
			if(is_array($items['acct']) === FALSE) {
					log_message('error', "'whm_get_accts()' server returned incorrect format as response to 'listaccts'. JSON: $json");
					return FALSE;
			}
			return $items['acct'];
	}
	
	function whm_get_reseller_accts($reseller, $user='root') {
			$accessHash = whm_get_access_hash();
			if($accessHash === FALSE) 
			{
					log_message('error', "'whm_get_reseller_accts()' no access hash available");
					return FALSE;
			}

			$context = stream_context_create( 
				array( 
					'http' => array(
						'method' => 'POST',
						'header' => "Authorization: WHM $user:".$accessHash."\r\n" 
					) 
				)
			);
			$json = file_get_contents(API_BASE_URL . 'json-api/resellerstats?reseller='.$reseller, false, $context);
			if($json === FALSE) {
					log_message('error', "'whm_get_reseller_accts()' failed getting reseller [$reseller] accounts list");
					return FALSE;
			}
			$json = utf8_encode($json);
			$items = json_decode($json, TRUE);
			if(is_array($items) === FALSE) {
					log_message('error', "'whm_get_reseller_accts()' failed decoding json response to 'resellerstats'");
					return FALSE;
			}
			if(is_array($items['result']['accts']) === FALSE) {
					log_message('error', "'whm_get_reseller_accts()' server returned incorrect format in response to 'resellerstats'");
					return FALSE;
			}
			return $items['result']['accts'];
	}
	
	function whm_get_ips($user='root') {
			$accessHash = whm_get_access_hash();
			if($accessHash === FALSE) 
			{
					log_message('error', "'whm_get_ips()' no access hash available");
					return FALSE;
			}
			$context = stream_context_create( 
				array( 
					'http' => array(
						'method' => 'POST',
						'header' => "Authorization: WHM $user:".$accessHash."\r\n" 
					) 
				)
			);
			$json = @file_get_contents(API_BASE_URL . 'json-api/listips', false, $context);
			if($json === FALSE) {
					log_message('error', "'whm_get_ips()' Failed to get ips list");
					return FALSE;
			}
			$json  = utf8_encode($json);
			$items = json_decode($json, TRUE);
			if(is_array($items) === FALSE) {
					log_message('error', "'whm_get_ips()' Failed to decode JSON response from listips query");
					return FALSE;
			}			
			if(is_array($items['result']) === FALSE) {
					log_message('error', "'whm_get_ips()' Failed to get ips list");
					return FALSE;
			}
			return $items['result'];
	}
	
	function whm_sorted_set($items, $key, $sort='asc'){
			$sorted_items = array();
			if(is_array($items))
			{
				foreach($items as $item)
				{
						if(!isset($item[$key])) continue;
						$sorted_items[$item[$key]] = $item;
				}
			}
			if(count($sorted_items)>0)
			{
					if($sort=='desc') 	krsort($sorted_items);
					else 				ksort($sorted_items);
					$items = $sorted_items;
			}
			return $items;
	}
	
	function whm_get_resellers($user='root') {
			$accessHash = whm_get_access_hash();
			if($accessHash === FALSE) 
			{
					log_message('error', "'whm_get_reseller_accts()' no access hash available");
					return FALSE;
			}
			$context = stream_context_create( 
				array( 
					'http' => array(
						'method' => 'POST',
						'header' => "Authorization: WHM $user:".$accessHash."\r\n" 
					) 
				)
			);
			$json = @file_get_contents(API_BASE_URL . 'json-api/listresellers', false, $context);
			if($json === FALSE) {
					log_message('error', "'whm_get_resellers()' failed getting resellers list");
					return FALSE;
			}
						
			$json = utf8_encode($json);
			$items = json_decode($json, TRUE);
			if(is_array($items) === FALSE) {
					log_message('error', "'whm_get_resellers()' failed decoding json response to 'listresellers'");
					return FALSE;
			}
			if(is_array($items['reseller']) === FALSE) {
					log_message('error', "'whm_get_resellers()' server returned incorrect format in response to 'listresellers'");
					return FALSE;
			}
			else
			{
				sort($items['reseller']);
			}				
			return $items['reseller'];
	}
	
	function whm_get_reseller_php_status() {
			$ret  = '';
			$file = '/var/cpanel/cpanel.config';
			$cmd  = "/usr/local/cpanel/whostmgr/bin/whostmgr2 --updatetweaksettings";
			if(is_file($file))
			{
					$data = file_get_contents($file);
					if(preg_match('#disable-php-as-reseller-security\s*=\s*1#is', $data))
					{
							$ret = 'ON';
					}
					elseif(preg_match('#disable-php-as-reseller-security\s*=\s*0#is', $data))
					{
							$ret = 'OFF';
					}
					else
					{
							$ret = 'OFF';
					}
			}
			return $ret;
	}
	
	function whm_enable_reseller_php() {
			$file = '/var/cpanel/cpanel.config';
			$cmd  = "/usr/local/cpanel/whostmgr/bin/whostmgr2 --updatetweaksettings";
			if(is_file($file))
			{
					$data = file_get_contents($file);
					if(!preg_match('#disable-php-as-reseller-security\s*=\s*1#is', $data))
					{
							if(preg_match('#disable-php-as-reseller-security\s*=\s*0#is', $data))
							{
									$data  = preg_replace('#disable-php-as-reseller-security\s*=\s*0#is',"\ndisable-php-as-reseller-security=1",$data);
							}
							else
							{
									$data .= "\ndisable-php-as-reseller-security=1";
							}
							if($fp = fopen($file,'wb+'))
							{
									fputs($fp,$data);
									fclose($fp);
									ob_start();
									$out = @system($cmd);
									ob_end_clean();
							}
					}
			}
	}
	
	function whm_disable_reseller_php() {
			$file = '/var/cpanel/cpanel.config';
			$cmd  = "/usr/local/cpanel/whostmgr/bin/whostmgr2 --updatetweaksettings";
			if(is_file($file))
			{
					$data = file_get_contents($file);
					if(preg_match('#disable-php-as-reseller-security\s*=\s*1#is', $data))
					{
							$data  = preg_replace('#disable-php-as-reseller-security\s*=\s*1#is',"\ndisable-php-as-reseller-security=0",$data);
							if($fp = fopen($file,'wb+'))
							{
									fputs($fp,$data);
									fclose($fp);
									ob_start();
									$out = @system($cmd);
									ob_end_clean();
							}
					}
			}
	}
	
	function whm_get_dns_zone($domain, $user='root') {
			$accessHash = whm_get_access_hash();
			if($accessHash === FALSE) 
			{
					log_message('error', "'whm_get_dns_zone()' no access hash available");
					return FALSE;
			}
			$context = stream_context_create( 
				array( 
					'http' => array(
						'method' => 'POST',
						'header' => "Authorization: WHM $user:".$accessHash."\r\n" 
					) 
				)
			);
			$json = @file_get_contents(API_BASE_URL . 'json-api/dumpzone?domain='.$domain, false, $context);
			if($json === FALSE) {
					log_message('error', "'whm_get_dns_zone()' Failed to get dns zones");
					return FALSE;
			}
			$json 	= utf8_encode($json);
			$items 	= json_decode($json, TRUE);
			if(is_array($items) === FALSE) {
					log_message('error', "'whm_get_dns_zone()' Failed to decode JSON response from dumpzone query");
					return FALSE;
			}
			if(is_array($items['result'][0]['record']) === FALSE) {
					log_message('error', "'whm_get_dns_zone()' Failed to get dsn zones");
					return FALSE;
			}
			return $items['result'][0]['record'];
	}
	
	function ipm_ip_usage_count($ip) {
			$cnt = 0;
			$stfile1 = '/etc/userdatadomains';
			$data = @file_get_contents($stfile1);
			$cnt = preg_match_all('#'.preg_quote($ip).'#is',$data,$matches);	
			if($cnt===FALSE) $cnt = 0;
			return $cnt;
	}
	
	function ipm_get_dedicated_ips() {
			$ret = array();
			$dir = 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$file = $dir . 'dedicated-ips.json';
			if(is_file($file))
			{
				$json = file_get_contents($file);
				$tmp  = json_decode($json, true);
				if(is_array($tmp)) $ret = $tmp;
			}
			return $ret;
	}
	
	function ipm_set_dedicated_ip($ip) {
			$dips = ipm_get_dedicated_ips();
			if(!in_array($ip, $dips)) 
			{
				$dips[] = trim($ip);
				$json = json_encode($dips);
				$dir = 'assets/data/';
				if(!is_dir($dir)) @mkdir($dir, 0755);
				$file = $dir . 'dedicated-ips.json';
				if($fp = fopen($file, 'wb+'))
				{
					fputs($fp, $json);
					fclose($fp);
				}
			}
			return ipm_get_dedicated_ips();
	}
	
	function ipm_release_dedicated_ip($ip) {
			$dips = ipm_get_dedicated_ips();
			if(in_array($ip, $dips)) 
			{
					$tmp = array();
					foreach($dips as $dip) if(trim($dip)==trim($ip)) continue; else $tmp[] = $dip; 
					$dips 	= $tmp;
					$json 	= json_encode($dips);
					$dir 	= 'assets/data/';
					if(!is_dir($dir)) @mkdir($dir, 0755);
					$file = $dir . 'dedicated-ips.json';
					if($fp = fopen($file, 'wb+'))
					{
						fputs($fp, $json);
						fclose($fp);
					}
			}
			return ipm_get_dedicated_ips();
	}
	
	function ipm_get_reseller_all_ips($unique=false) {
			$ret 	= array();
			$dir 	= 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$file 	= $dir . 'resellers-ips.json';
			if(is_file($file))
			{
					$json 	= file_get_contents($file);
					$items  = json_decode($json, true);
					if(is_array($items)) 
					{
							foreach($items as $reseller=>$ips)
							{
									foreach($ips as $ip) if($unique && in_array($ip, $ret)) continue; else $ret[] = $ip;
							}
					}
			}
			return $ret;
	}
	
	function ipm_get_reseller_ips($reseller) {
			$ret 	= array();
			$dir 	= 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$file 	= $dir . 'resellers-ips.json';
			if(is_file($file))
			{
					$json 	= file_get_contents($file);
					$items  = json_decode($json, true);
					if(isset($items[$reseller])) $ret = $items[$reseller];
			}
			return $ret;
	}
	
	function ipm_assign_reseller_ip($reseller, $ip) {
			$dir 	= 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$file 	= $dir . 'resellers-ips.json';
			$json 	= @file_get_contents($file);
			$items  = json_decode($json, true);
			if(!is_array($items)) $items = array();
			if(isset($items[$reseller]) && !in_array($ip, $items[$reseller])) $items[$reseller][] = $ip;
			else $items[$reseller][] = $ip;
			if(count($items)>0)
			{
					$json = json_encode($items);
					if($json && $fp = fopen($file, 'wb+'))
					{
							fputs($fp, $json);
							fclose($fp);
					}
			}
	}
	
	function ipm_unassign_reseller_ip($reseller, $ip) {
			$dir 	= 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$file 	= $dir . 'resellers-ips.json';
			if(is_file($file))
			{
					$json 	= file_get_contents($file);
					$items  = json_decode($json, true);
					if(isset($items[$reseller]))
					{
							$tmp = array();
							foreach($items[$reseller] as $tmp_ip) if($tmp_ip!=$ip) $tmp[] = $tmp_ip;
							$items[$reseller] = $tmp;
					}
					if(count($items)>0)
					{
							$json = json_encode($items);
							if($json && $fp = fopen($file, 'wb+'))
							{
									fputs($fp, $json);
									fclose($fp);
							}
					}
			}
	}
	
	function ipm_change_site_ip($newip, $user, $domain, $restart_apache=false) {
			log_message('debug', "'ipm_change_site_ip()' parameters(newip=$newip, user=$user, domain=$domain,restart_apache=$restart_apache)");
			if(!$newip) 
			{
					log_message('error', "'ipm_change_site_ip()' [$domain] missing new ip");
					return false;
			}
			if(!$user) 
			{
					log_message('error', "'ipm_change_site_ip()' [$domain] missing account username");
					return false;
			}
			if(!$domain) 
			{
					log_message('error', "'ipm_change_site_ip()' [$domain] missing domain name");
					return false;
			}
			$oldip 	= '';
			$zones  = whm_get_dns_zone($domain);
			if(!is_array($zones) OR count($zones)==0)
			{
					log_message('error', "'ipm_change_site_ip()' [$domain] no DNS zone found for this domain");
					return false;
			}
			
			$time = time();
			foreach($zones as $zone)
			{
					if ( @$zone['type']=='A' && preg_match('#^'.preg_quote($domain).'\.$#is', trim($zone['name'])))
					{
								$oldip = $zone['address'];
								break;
					}
			}
			if(!$oldip) 
			{
					log_message('error', "'ipm_change_site_ip()' [$domain] could not found old ip");
					return false;
			}
			
			log_message('debug', "'ipm_change_site_ip()' [$domain] changing ip from [$oldip] to [$newip]");
			$user_store_updated = false;
			
			// update user datastore
			$dir = "/var/cpanel/userdata/$user";
			if(!is_dir($dir))
			{
					log_message('debug', "'ipm_change_site_ip()' [$domain] $dir is not a directory");
			}
			elseif ($handle = opendir($dir)) {
				while (false !== ($file = readdir($handle))) {
					if(is_dir($dir.'/' .$file)) continue;
					$data = file_get_contents($dir.'/'.$file);
					if(preg_match('#'.preg_quote($oldip).'#is', $data))
					{
							$data = preg_replace('#'.preg_quote($oldip).'#is',$newip,$data);
							if(preg_match('#'.preg_quote($newip).'#is', $data) && $fp = fopen($dir.'/'.$file, 'wb+'))
							{
									fputs($fp,$data);
									fclose($fp);
									$user_store_updated = true;
									log_message('debug', "'ipm_change_site_ip()' [$domain] $dir successfully updated to new IP ($newip)");
							}
							else
							{
									log_message('debug', "'ipm_change_site_ip()' [$domain] Failed updating $dir to new IP ($newip)");
							}
					}
					else
					{
							log_message('debug', "'ipm_change_site_ip()' [$domain] $oldip not found in {$dir}/{$file}");
					}
				}
				closedir($handle);
				
				$backup_dir = 'assets/data/backup/'.strtolower($domain).'/';
				if(!is_dir($backup_dir)) @mkdir($backup_dir, 0755, true);
				
				$stfile1 = '/etc/userdatadomains';
				$stfile2 = '/etc/userdatadomains.stor';				
				
				@copy($stfile1, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-before_'.$time);
				@copy($stfile2, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-before_'.$time);
				
				$new_data = '';
				if($fp = fopen($stfile1, 'r'))
				{
						while(!feof($fp))
						{
							$line = fgets($fp, 4096);
							if(preg_match('#'.preg_quote($domain).'#is', $line) && preg_match('#'.preg_quote($user).'#is', $line))
							{
									$line = preg_replace('#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}#is', $newip, $line);
									if(preg_match('#'.preg_quote($newip).'#is', $line))
									{
											log_message('debug', "'ipm_change_site_ip()' [$domain] $newip updated in $stfile1");
									}
									else
									{
											log_message('debug', "'ipm_change_site_ip()' [$domain] Failed updating $newip in $stfile1");
									}
							}
							$new_data .= $line;
						}
						fclose($fp);
				}
				if($new_data && $fp = fopen($stfile1, 'wb+'))
				{
						fwrite($fp, $new_data, strlen($new_data));
						fclose($fp);
				}
				$new_data = '';
				if($fp = fopen($stfile2, 'rb'))
				{
						$repl_on = false;
						$repl_no = false;
						while(!feof($fp))
						{
							$line = fgets($fp, 4096);
							if(preg_match('#'.preg_quote($domain).'#is', $data))
							{
									$repl_on = true;
							}
							if(!$repl_no && $repl_on && preg_match('#'.preg_quote($oldip).'#is', $line))
							{
									$line 		= preg_replace('#'.preg_quote($oldip).'#is', $newip, $line);
									$repl_no 	= true;
									if(preg_match('#'.preg_quote($newip).'#is', $line))
									{
											log_message('debug', "'ipm_change_site_ip()' [$domain] $newip updated in $stfile2");
									}
									else
									{
											log_message('debug', "'ipm_change_site_ip()' [$domain] Failure updating $newip in $stfile2");
									}
							}
							$new_data .= $line;
						}
						fclose($fp);
				}
				if($new_data && $fp = fopen($stfile2, 'wb+'))
				{
						fwrite($fp, $new_data, strlen($new_data));
						fclose($fp);
				}
				@copy($stfile1, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-after_'.$time);
				@copy($stfile2, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-after_'.$time);
			}
			else
			{
					log_message('debug', "'ipm_change_site_ip()' [$domain] Failure opening $dir");
			}
			
			if($user_store_updated)
			{
					log_message('debug', "'ipm_change_site_ip()' [$domain] userdata for user $user updated");
					
					// Update DNS records
					ob_start();
					$out = system("/usr/local/cpanel/bin/swapip $oldip $newip $newip $domain");
					ob_end_clean();
					log_message('debug', "'ipm_change_site_ip()' [$domain] DNS Update -> $out");
					
					//  Rebuild httpd.conf
					ob_start();
					$out = @system("/scripts/rebuildhttpdconf");
					ob_end_clean();
					log_message('debug', "'ipm_change_site_ip()' [$domain] Rebuild httpd.conf -> $out");
					
					// restart Apache
					if($restart_apache)
					{
							ob_start();
							$out = @system("service httpd restart");
							ob_end_clean();
							log_message('debug', "'ipm_change_site_ip()' [$domain] service httpd restart -> $out");
					}
					log_message('debug', "'ipm_change_site_ip()' [$domain] ip changed from [$oldip] to [$newip]");
					return true;
			}
			else
			{
					log_message('debug', "'ipm_change_site_ip()' [$domain] failed changing ip from [$oldip] to [$newip]");
					return false;
			}
	}
		
	function ipm_update_domain($newip, $user, $domain){
			$time = time();
			log_message('debug', "'ipm_update_domain()' parameters(newip=$newip, user=$user, domain=$domain)");
			if(!$newip) 
			{
					log_message('error', "'ipm_update_domain()' [$domain~$newip] missing new ip");
					return false;
			}
			if(!$user) 
			{
					log_message('error', "'ipm_update_userdata()' [$domain~$newip] missing account username");
					return false;
			}
			if(!$domain) 
			{
					log_message('error', "'ipm_update_userdata()' [$domain~$newip] missing domain name");
					return false;
			}
			$oldip 	= '';
			$zones  = whm_get_dns_zone($domain);
			if(!is_array($zones) OR count($zones)==0)
			{
					log_message('error', "'ipm_update_domain()' [$domain~$newip] no DNS zone found for this domain");
					return false;
			}
			foreach($zones as $zone)
			{
					if ( @$zone['type']=='A' && preg_match('#^'.preg_quote($domain).'\.$#is', trim($zone['name'])))
					{
								$oldip = $zone['address'];
								break;
					}
			}
			if(!$oldip) 
			{
					log_message('error', "'ipm_update_domain()' [$domain~$newip] could not found old ip");
					return false;
			}
			
			log_message('debug', "'ipm_update_domain()' [$domain~$newip] changing ip from [$oldip] to [$newip] for domain [$domain]");
			
			$dir = "/var/cpanel/userdata/$user";
			if(!is_dir($dir))
			{
					log_message('error', "'ipm_update_domain()' [$domain~$newip] $dir is not a directory");
					return false;
			}
			elseif ($handle = opendir($dir)) {
				while (false !== ($file = readdir($handle))) {
					if(is_dir($dir.'/' .$file)) continue;
					$data = file_get_contents($dir.'/'.$file);
					if(preg_match('#'.preg_quote($oldip).'#is', $data))
					{
							$data = preg_replace('#'.preg_quote($oldip).'#is',$newip,$data);
							if(preg_match('#'.preg_quote($newip).'#is', $data) && $fp = fopen($dir.'/'.$file, 'wb+'))
							{
									fputs($fp,$data);
									fclose($fp);
									log_message('debug', "'ipm_update_domain()' [$domain~$newip] $dir successfully updated to new IP ($newip)");
							}
							else
							{
									log_message('error', "'ipm_update_domain()' [$domain~$newip] Failed updating $dir to new IP ($newip)");
							}
					}
					else
					{
							log_message('error', "'ipm_update_domain()' [$domain~$newip] $oldip not found in {$dir}/{$file}");
					}
				}
				closedir($handle);
				
				$backup_dir = 'assets/data/backup/'.strtolower($domain).'/';
				if(!is_dir($backup_dir)) @mkdir($backup_dir, 0755, true);
				
				$stfile1 = '/etc/userdatadomains';
				$stfile2 = '/etc/userdatadomains.stor';				
				
				@copy($stfile1, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-before_'.$time);
				@copy($stfile2, $backup_dir . preg_replace('#\/#is', '_', $stfile2).'-before_'.$time);
				
				$new_data = '';
				if($fp = fopen($stfile1, 'r'))
				{
						while(!feof($fp))
						{
							$line = fgets($fp, 4096);
							if(preg_match('#'.preg_quote($domain).'#is', $line) && preg_match('#'.preg_quote($user).'#is', $line))
							{
									$line = preg_replace('#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}#is', $newip, $line);
									if(preg_match('#'.preg_quote($newip).'#is', $line))
									{
											log_message('debug', "'ipm_update_domain()' [$domain~$newip] $newip updated in $stfile1");
									}
									else
									{
											log_message('debug', "'ipm_update_domain()' [$domain~$newip] Failed updating $newip in $stfile1");
									}
							}
							$new_data .= $line;
						}
						fclose($fp);
				}
				if($new_data && $fp = fopen($stfile1, 'wb+'))
				{
						fwrite($fp, $new_data, strlen($new_data));
						fclose($fp);
				}
				else
				{
						log_message('debug', "'ipm_update_domain()' [$domain~$newip] Failed updating $stfile1");
						return false;
				}
									
				$new_data = '';
				if($fp = fopen($stfile2, 'rb'))
				{
						$repl_on = false;
						$repl_no = false;
						while(!feof($fp))
						{
							$line = fgets($fp, 4096);
							if(preg_match('#'.preg_quote($domain).'#is', $data))
							{
									$repl_on = true;
							}
							if(!$repl_no && $repl_on && preg_match('#'.preg_quote($oldip).'#is', $line))
							{
									$line 		= preg_replace('#'.preg_quote($oldip).'#is', $newip, $line);
									$repl_no 	= true;
									if(preg_match('#'.preg_quote($newip).'#is', $line))
									{
											log_message('debug', "'ipm_update_domain()' [$domain~$newip] $newip updated in $stfile2");
									}
									else
									{
											log_message('debug', "'ipm_update_domain()' [$domain~$newip] Failure updating $newip in $stfile2");
									}
							}
							$new_data .= $line;
						}
						fclose($fp);
				}
				if($new_data && $fp = fopen($stfile2, 'wb+'))
				{
						fwrite($fp, $new_data, strlen($new_data));
						fclose($fp);
				}
				else
				{
						log_message('debug', "'ipm_update_domain()' [$domain~$newip] Failed updating $stfile2");
						return false;
				}
				@copy($stfile1, $backup_dir . preg_replace('#\/#is', '_', $stfile1).'-after_'.$time);
				@copy($stfile2, $backup_dir . preg_replace('#\/#is', '_', $stfile2).'-after_'.$time);
				
				return true;
			}
			else
			{
					log_message('error', "'ipm_update_domain()' [$domain~$newip] Failure opening $dir");
					return false;
			}
	}
	
	function ipm_swaip($oldip, $newip, $ftpip, $domain,$user){
			log_message('debug', "'ipm_swaip()' parameters(oldip=$oldip, newip=$newip, ftpip=$ftpip, domain=$domain)");
			if($oldip==$newip)
			{
					log_message('debug', "'ipm_swaip()' Old and New IPs are the same");
					return false;
			}
			ob_start();
			$out = system("/usr/local/cpanel/bin/setsiteip -u $user $newip");
			ob_end_clean();
			log_message('debug', "'ipm_swaip()' /usr/local/cpanel/bin/setsiteip -u $user $newip -> $out");
			return true;
	}
	
	function ipm_rebuild_httpd_conf(){
			ob_start();
			$out = @system("/scripts/rebuildhttpdconf");
			ob_end_clean();
			log_message('debug', "'ipm_rebuild_httpd_conf()' /scripts/rebuildhttpdconf -> $out");
			return true;
	}
	
	function ipm_reboot_apache(){
			ob_start();
			$out = @system("service httpd restart");
			ob_end_clean();
			log_message('debug', "' ipm_reboot_apache()' service httpd restart -> $out");
			return true;
	}
	
	function ipm_is_ip_free($ip) {
			$data 		= @file_get_contents('/usr/local/apache/conf/httpd.conf');
			if(preg_match('#<VirtualHost\s+'.preg_quote($ip).':80>#is', $data)) return true;
			else return false;
	}
	
	function ipm_used_ips() {
			$ret   = array();
			$accts = whm_get_accts();
			if(is_array($accts)) {
					foreach($accts as $acct) 
					{
							$ret[] = $acct['ip'];
					}
					$ret = array_unique($ret);
			}
			return $ret;
	}
	
	function imp_log_ip_change($domain, $ip){
			$dir = 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$json = @file_get_contents($dir . 'ip-changes.json');
			$items = json_decode($json, TRUE);
			if(!is_array($items)) $items = array();
			$items[$domain] = array('updated'=>time(), 'ip'=>$ip);
			$json = json_encode($items);
			if($json && $fp = fopen($dir . 'ip-changes.json', 'wb'))
			{
					fputs($fp, $json);
					fclose($fp);
			}
			return true;
	}
	
	function ipm_backup(){
			$time = time();
			$backup_dir = 'assets/data/';
			if(!is_dir($backup_dir)) 			@mkdir($backup_dir, 0755, true);
			if(!is_dir($backup_dir.'backup/')) 	@mkdir($backup_dir, 0755, true);
			$src  = $backup_dir;
			$dest = $backup_dir . 'backup/backup-' . $time . '.zip';
			ob_start();
			$out = @system("zip -r $dest $src");
			ob_end_clean();
			if(preg_match('#command\s*not\s*found#is', $out))
			{
					$dest = $backup_dir . 'backup-' . $time . '.gzip';
					ob_start();
					$out  = @system("gzip -r $dest $src");
					ob_end_clean();
					if(!preg_match('#command\s*not\s*found#is', $out)) return false;
			}
			return true;
	}
	
	function ipm_get_backups(){
			$items = array();
			$backup_dir = 'assets/data/backup/';
			if ($handle = opendir($backup_dir)) 
			{
					while (false !== ($file = readdir($handle))) 
					{
							if(preg_match('#^backup-\d{10}\.g?zip$#is', $file))
							{
									$items[] = $file;
							}
					}
			}
			return $items;
	}
	
	function imp_log_user_msg($msg){
			$date = date('Y-m-d');
			$dir = 'assets/data/';
			if(!is_dir($dir)) @mkdir($dir, 0755);
			$json = @file_get_contents($dir . 'logs-'.$date.'.json');
			$items = json_decode($json, TRUE);
			if(!is_array($items)) $items = array();
			$items[] = date('m/d/Y h:i:s A T') . "\t" . $msg;
			$json = json_encode($items);
			if($json && $fp = fopen($dir . 'logs-'.$date.'.json', 'wb'))
			{
					fputs($fp, $json);
					fclose($fp);
			}
			return true;
	}
	
	function log_message($level = 'error', $msg, $php_error = FALSE) {
		$_levels = array('ERROR' => '1', 'DEBUG' => '2',  'INFO' => '3', 'ALL' => '4');

		if (LOG_THRESHOLD == 0)
		{
			return;
		}

		$level = strtoupper($level);

		if ( ! isset($_levels[$level]) OR ($_levels[$level] > LOG_THRESHOLD))
		{
			return FALSE;
		}

		$filepath = BASE_PATH.'application/logs/log-'.date('Y-m-d').'.log';
		$message  = '';

		if ( ! file_exists($filepath))
		{
			// $message .= "";
		}

		if ( ! $fp = @fopen($filepath, 'ab'))
		{
			return FALSE;
		}

		$message .= $level."\t".date('m/d/Y h:i:s A T')."\t".$msg."\n";

		flock($fp, LOCK_EX);
		fwrite($fp, $message);
		flock($fp, LOCK_UN);
		fclose($fp);

		@chmod($filepath, 0666);
		return TRUE;
		
	}

/* End of file Common.php */
/* Location: ./system/core/Common.php */
