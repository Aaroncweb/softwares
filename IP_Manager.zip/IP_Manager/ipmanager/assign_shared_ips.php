<?php
		
		require_once('libraries/cpanel-xmlapi-php/xmlapi.php');
		require_once('functions.php');
		
		$acl = checkacl ('all');
		
		if(!$acl)
		{
				header("Location: ".$_ENV{'cp_security_token'}."/ipmanager/index.php");
				exit();
		}
		
		if ( @$_POST['cmd']=='assign_reseller_ips' && @$_POST['reseller'] && isset($_POST['ips']) && count($_POST['ips'])>0) {
				$assigned_ips 		= get_assigned_ips();
				$dedicated_ips 		= getDedicatedIPsList();
				$reseller_ips_pool 	= get_reseller_assigned_ips($_POST['reseller']);
				$wlist				= array();
				
				foreach($_POST['ips'] as $ip) 
				{
						if(!in_array($ip, $reseller_ips_pool) && !(in_array($ip, $dedicated_ips) && in_array($ip, $assigned_ips)) )
						{
							$wlist[] = $ip;
						}
				}
				
				$ips = assign_reseller_ips($_POST['reseller'], $wlist);
				
				$notice 	= '';
				$notice2 	= '';
				foreach($_POST['ips'] as $ip) 
				{
						if(in_array($ip, $reseller_ips_pool))
						{
								$notice2 .= ($notice2?", ":"The following ip address(es) are already assigned to [".$_POST['reseller']."]: \n") . $ip;
						}
						elseif(in_array($ip, $dedicated_ips) && in_array($ip, $assigned_ips))
						{
								$notice .= ($notice?", ":"The following ip address(es) cannot be assigned\nbecause they are dedicated and already assigned to another reseller: \n") . $ip;
						}
				}
				$notice .= ($notice ? "\n\n" : "") . $notice2;
				
				die(json_encode(array('stat'=>'success', 'ips'=>get_reseller_assigned_ips($_POST['reseller']), 'notice'=>$notice)));
		}
		elseif ( @$_POST['cmd']=='get_dips' && @$_POST['reseller']) {
				$dips = get_reseller_dips($_POST['reseller']);
				die(json_encode(array('stat'=>'success', 'dips'=>$dips)));
		}
		elseif ( @$_POST['cmd']=='get_reseller_assigned_ips' && @$_POST['reseller']) {
				$assigned_ips = get_reseller_assigned_ips($_POST['reseller']);
				die(json_encode(array('stat'=>'success', 'assigned_ips'=>$assigned_ips)));
		}
		elseif ( @$_POST['cmd']=='get_resellers') {
				$ips = get_assigned_ips();
				$dedicated_ips = getDedicatedIPsList();
				$content 	 = '';
				$resellersList = getResellersList();
				foreach($ips as $reseller=>$items) {
						if(!in_array($reseller,$resellersList)) continue;
						$list = '';
						foreach($items as $item) if(!in_array($item, $dedicated_ips)) $list .= ($list?', ':'') . "<a style=\"".(in_array($item, $dedicated_ips)?'font-weight:bold;':'')."\" href=\"javascript:void(0);\" onclick=\"jx_delete_reseller_assigned_ip('$reseller','$item');\">$item</a>";
						$content .= '<tr>
							<td><a href="javascript:void(0);" onclick="jQuery(\'#reseller\').val(\''.$reseller.'\');jQuery(\'#reseller\').trigger(\'change\');">'.$reseller.'</a>&nbsp;</td>
							<td>'.$list.'</td>
						</tr>'."\n";
				}
				$content = '<tr>
					<th>Reseller&nbsp;</th>
					<th>Assigned IPs <small style="color:#ff0000;" title="Click any IP below to remove it">?</small>&nbsp;</th>
				</tr>'."\n" . $content;
				if($content)
				{
						$content = "<table cellspacing=\"0\" cellpadding=\"0\">$content</table>";
				}
				die(json_encode(array('stat'=>'success', 'content'=> $content)));
		}
		elseif ( @$_POST['cmd']=='delete_reseller_assigned_ip' && @$_POST['reseller'] && @$_POST['ip']) {
				$ips = unassign_reseller_ips($_POST['reseller'], array($_POST['ip']));
				die(json_encode(array('stat'=>'success', 'ips'=>$ips)));
		}
		elseif ( @$_POST['cmd']=='load_free_ips') {
				$WHMIPsList 	= getIPsList();
				$assigned_ips   = array();
				$tmp			= get_assigned_ips();
				foreach($tmp as $items)
				{
					foreach($items as $item)
					{
							$assigned_ips[] = $item;
					}
				}
				$items = array();
				$dedicated_ips 	= getDedicatedIPsList();
				foreach($WHMIPsList as $ip) if(in_array($ip['ip'], $dedicated_ips)) continue; else $items[] = $ip['ip'];
				die(json_encode(array('stat'=>'success', 'ips'=>$items)));
		}
		
		$resellersList 	= getResellersList();
		$WHMIPsList  	= getIPsList();
		$assigned_ips   = array();
		$tmp			= get_assigned_ips();
		foreach($tmp as $items)
		{
			foreach($items as $item)
			{
					$assigned_ips[] = $item;
			}
		}	
		$dedicated_ips = getDedicatedIPsList();
		// print_r($assigned_ips);
		$php_rs = reseller_php_status();
		
		$ips = get_assigned_ips();
		// print_r($ips);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <title>IP Manager WHM Plugin</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="<?=$_ENV{cp_security_token};?>/ipmanager/css/style.css" media="screen" type="text/css" />
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>

  <style type="text/css">
		
		ul.form label {
				display: inline-block;
				line-height: 1.8;
				vertical-align: top;
		}
		
		ul.form li {
			  padding: 5px;
			  margin: 0;
		}
		
		ul.form li label {
				width: 120px; /* Width of labels */
				font-size: 14px;
		}
		
		.error {
				font-weight:bold;
				color:#ff0000;
		}
		
  </style>
  
</head>

<body id="body">
<a href="<?=BASE_URL;?><?=WHM_TOKEN;?>">Back to WHM</a>
<div id="toppromo" style="display:none;">
</div>


<div id="Container">


<div id="Header">
  <div id="Nav" style="line-height: 57px; padding-right: 40px;">
    <h1>IP Manager<?php echo ($acl?" &dash; Admin":" &dash; Reseller"); ;?></h1>
   </div>
</div>

<div class="Left">
  <div class="col"> 
  
    <div class="recent">
      <h1>Assign Shared IP to resellers</h1>
    </div>
	<form id="main_form" name="main_form">
	<ul class="form">
		<li>
			<label for="reseller">Reseller</label> 
			<select id="reseller" name="reseller">
					<option value="">Choose Reseller</option>
					<?php
						foreach($resellersList as $reseller) {
								echo "<option value=\"$reseller\">$reseller</option>\n";
						}
					?>
			</select>&nbsp;<img id="icon-act_reseller" src="<?=$_ENV{cp_security_token};?>/ipmanager/images/busy.gif" style="display: none;vertical-align:middle;" />
			<span id="error-reseller" class="error"></span>
		</li>
		<li>
			<label for="dips">IP Address(es)</label>
			<select id="dips" name="dips" multiple="multiple" size="10">
					<option value="">Choose IP Address</option>
					<?php
						// $ip['mainaddr'] $ip['dedicated'] $ip['used']
						foreach($WHMIPsList as $ip) {	
								if(in_array($ip['ip'], $dedicated_ips)) continue;
								echo "<option value=\"{$ip['ip']}\">{$ip['ip']}</option>\n";
						}
					?>
			</select>&nbsp;
			<span id="error-dips" class="error"></span>
		</li>
		<li>
			<div class="buttonblock">
				<input type="submit" id="btAssign" value="Assign" style="font-weight: bold;"> 
			</div>
		</li>
		<li id="activity-report"></li>
	</ul>
	</form>
	
	<div id="resellers-list"></div>
	
	<script language="javascript">
			jQuery('#main_form').bind('submit', function() {
					jx_assign_reseller_ips();
					return false;
			});
			
			jQuery('#reseller').bind('change', function() {
					if(this.value) jx_get_reseller_assigned_ips();
					else $("#dips option:disabled").attr("disabled", false);
			});
			
			jQuery(document).ready(function(){
					jx_get_resellers();
					
					
					jQuery('#php-rs_enable').bind('click', function() {
							jQuery('#php_rs-act').show();
							jQuery.ajax({
									type: "POST",
									url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/index.php",
									cache: false,
									data: 'cmd=php_reseller_enable',
									success: function(msg){
											jQuery('#php_rs-act').hide();
											// alert(msg);
											try {
													var _obj = jQuery.parseJSON(msg);
													if(_obj.stat=='success')
													{
														jQuery('#php-rs_enable').hide();
														jQuery('#php-rs_disable').show();
														jQuery('#php-rs_on').show();
														jQuery('#php-rs_off').hide();
													}
											} catch(err) { }
									},
									error:function (xhr, ajaxOptions, thrownError){
											jQuery('#php_rs-act').hide();
											// alert(xhr.responseText);
									}
							});
					});

					jQuery('#php-rs_disable').bind('click', function() {
							jQuery('#php_rs-act').show();
							jQuery.ajax({
									type: "POST",
									url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/index.php",
									cache: false,
									data: 'cmd=php_reseller_disable',
									success: function(msg){
											jQuery('#php_rs-act').hide();
											// alert(msg);
											try {
													var _obj = jQuery.parseJSON(msg);
													if(_obj.stat=='success')
													{
														jQuery('#php-rs_enable').show();
														jQuery('#php-rs_disable').hide();
														jQuery('#php-rs_on').hide();
														jQuery('#php-rs_off').show();
													}
											} catch(err) { }
									},
									error:function (xhr, ajaxOptions, thrownError){
											jQuery('#php_rs-act').hide();
											// alert(xhr.responseText);
									}
							});
					});
					
			});
			
			function jx_assign_reseller_ips() 
			{
					jQuery('#error-reseller').html('');
					if ( !jQuery('#reseller').val())
					{
							jQuery('#error-reseller').html('<br /><label for=""></label>Please choose a reseller.');
							return false;
					} 
					var postdata = 'reseller='+jQuery('#reseller').val();
					var dips = jQuery('#dips option:selected');
					var cnt = dips.length;
					dips.each(function(){
							if(jQuery(this).val()) postdata = postdata + "&ips"+encodeURIComponent(jQuery.trim("[]"))+"=" + encodeURIComponent(jQuery.trim(jQuery(this).val()));
							else cnt--;
					});
					if(cnt==0)
					{
							jQuery('#error-dips').html('<br /><label for=""></label>Please choose at least one IP address.');
							return false;
							// postdata = postdata + "&dips"+encodeURIComponent(jQuery.trim("[]"))+"=" + '';
					}
					postdata = postdata + "&cmd=assign_reseller_ips";
					
					jQuery('#btAssign').attr('disabled', true);
					jQuery.ajax({
							type: "POST",
							url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/assign_shared_ips.php",
							cache: false,
							data: postdata,
							success: function(msg){
									jQuery('#btAssign').attr('disabled', false);
									// alert(msg);
									
									try {
										var _obj = jQuery.parseJSON(msg);
										if(_obj.stat=='success')
										{
												if(_obj.content)
												{
														jQuery('#resellers-list').html(_obj.content);
												}
												
												if(_obj.notice)
												{
													alert(_obj.notice);
												}
										}
									} catch(err) { }
									
									jx_get_resellers();
									jx_load_free_ips();
							},
							error:function (xhr, ajaxOptions, thrownError){
									jQuery('#btAssign').attr('disabled', false);
									// alert(xhr.responseText);
							}
					});
			}
			
			function jx_get_reseller_assigned_ips() 
			{
					jQuery('#icon-act_reseller').show();
					var postdata = 'reseller='+jQuery('#reseller').val();
					postdata = postdata + "&cmd=get_reseller_assigned_ips";
					jQuery.ajax({
							type: "POST",
							url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/assign_shared_ips.php",
							cache: false,
							data: postdata,
							success: function(msg){
									jQuery('#icon-act_reseller').hide();
									// alert(msg);
									var jobj = jQuery.parseJSON(msg);
									if(typeof jobj.stat!='undefined')
									{
										if(jobj.stat=='success' && typeof jobj.assigned_ips!='undefined')
										{
											var ips_list = jobj.assigned_ips;
											$("#dips option:disabled").attr("disabled", false);
											jQuery.each(ips_list, function(index,value){
													jQuery("#dips option[value='" + value + "']").attr("disabled", true);
											});
										}
									}
							},
							error:function (xhr, ajaxOptions, thrownError){
									jQuery('#icon-act_reseller').hide();
									alert(xhr.responseText);
							}
					});
			}
			
			function jx_delete_reseller_assigned_ip(reseller,ip) {
			
					if(!confirm('Are you sure that you want to UN-ASSIGN IP address ['+ip+'] from reseller ['+reseller+']?')) return false;
					var postdata = 'reseller='+reseller;
					postdata 	 = postdata + "&ip=" + ip;
					postdata 	 = postdata + "&cmd=delete_reseller_assigned_ip";
					jQuery.ajax({
							type: "POST",
							url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/assign_shared_ips.php",
							cache: false,
							data: postdata,
							success: function(msg){
									// alert(msg);
									jx_get_resellers();
									jx_load_free_ips();
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert(xhr.responseText);
							}
					});
			}
			
			function jx_get_resellers()   {
			
					var postdata = "cmd=get_resellers";
					jQuery.ajax({
							type: "POST",
							url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/assign_shared_ips.php",
							cache: false,
							data: postdata,
							success: function(msg){
									// alert(msg);
									try {
										var _obj = jQuery.parseJSON(msg);
										if(_obj.stat=='success')
										{
												if(_obj.content)
												{
														jQuery('#resellers-list').html(_obj.content);
												}
										}
									} catch(err) { }
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert(xhr.responseText);
							}
					});
					
			}
			
			function jx_load_free_ips() {
			
					var postdata = "cmd=load_free_ips";
					jQuery.ajax({
							type: "POST",
							url: "<?php echo $server_url?><?=$_ENV{cp_security_token};?>/ipmanager/assign_shared_ips.php",
							cache: false,
							data: postdata,
							success: function(msg){
									// alert(msg);
									try {
										var _obj = jQuery.parseJSON(msg);
										if(_obj.stat=='success')
										{
												if(_obj.ips)
												{
														var options = jQuery("#dips");
														options.empty();
														options.append(jQuery("<option />").val('').html('Choose IP Address'));
														jQuery.each(_obj.ips, function(index,value) {
																options.append(jQuery("<option />").val(value).html(value));
														});
												}
										}
									} catch(err) { }
							},
							error:function (xhr, ajaxOptions, thrownError){
									// alert(xhr.responseText);
							}
					});
			}

	</script>
  

  </div>
</div>



<div class="Right">
  <div class="col" style="border: none;">
    <div class="Sidebar">
      <div class="greyoutlinebox">
        <h2>Need help?</h2>
        <p>Check out the <a href="<?=$_ENV{cp_security_token};?>/ipmanager/help.php">FAQs</a></p>
      
	    <?php
			if($acl) {
		?>
		<h2>Dedicated IPs</h2>
        <p>
          <a href="<?=$_ENV{cp_security_token};?>/ipmanager/dedicated_ips.php">Dedicated IPs</a>
        </p>
		
		<h2>Assign Dedicated IP</h2>
        <p>
          <a href="<?=$_ENV{cp_security_token};?>/ipmanager/assign_dedicated_ips.php">Assign Dedicated IP to resellers</a>
        </p>
		
		<h2>Nameservers</h2>
        <p>
          <a href="<?=$_ENV{cp_security_token};?>/ipmanager/custom_nameservers.php">Custom nameservers</a>
        </p>
		
		<h2>PHP For Reseller</h2>
        <p>
			Status: <span id="php-rs_on" style="color:#00ff00;<?php echo ($php_rs=='ON'?'display:inline;':'display:none'); ?>">ON</span> <span id="php-rs_off" style="color:#ff0000;<?php echo ($php_rs=='OFF'?'display:inline;':'display:none'); ?>">OFF</span>
			(<a href="#" id="php-rs_enable" style="<?php echo ($php_rs=='OFF'?'display:inline;':'display:none;'); ?>">Enable</a><a href="#" id="php-rs_disable" style="<?php echo ($php_rs=='ON'?'display:inline;':'display:none;'); ?>">Disable</a><span id="php_rs-act" style="display:none;">&nbsp;<img style="vertical-align:middle;" src="<?php echo $server_url?><?php echo $_ENV{cp_security_token}; ?>/ipmanager/images/busy.gif" /></span>)
        </p>
		
		<p>
          <a href="<?=$_ENV{cp_security_token};?>/ipmanager/index.php">&laquo; Back home</a>
        </p>
		<?php
			}
		?>
		
	  </div>
    </div>
  </div>
  <img src="http://www.seohost.com/wp-content/themes/seohost/images/logo.png" alt="Logo"/>
</div>


  
<div id="footer">
  Copyright &copy; 2012 SeoHost.com. All rights reserved.<br />
</div>

</div>

</body>

</html>
