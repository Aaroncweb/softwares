<?php
		define('BASE_PATH', '');
		require_once(BASE_PATH . 'system/core/Bootstrap.php');
		
		$reseller = @$_GET['reseller'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta charset="UTF-8" />
	<title>IP Manager WHM Plugin</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/css/style.css" media="screen" type="text/css" />
	<link rel="stylesheet" href="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/base/jquery-ui.css" />
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
	<script type="text/javascript" src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<script src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/ipmanager.js"></script>
	<script language="javascript">
		var __base_url 			= '<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/';
		var default_reseller 	= '<?=$reseller?>';
		jQuery(document).ready(function(){
				IPManager.ResellersIpPool.getDedicatedList(false, 1);
		});
	</script>
</head>

<body id="body">
<div id="toppromo" style="display:none;"></div>


<div id="Container">


<div id="Header" style="margin-bottom:10px;">
  <div id="Nav" style="line-height: 57px; padding-right: 40px;">
		<h2>Select a dedicated IP address for reseller [<?php echo $reseller; ?>]</h2>
   </div>
</div>

<div class="Left">
  <div class="col">
	
	<div id="ips-list"></div>
	
  </div>
</div>
  
<div id="footer">
  Copyright &copy; 2012 SeoHost.com. All rights reserved.<br />
</div>

</div>

</body>

</html>
