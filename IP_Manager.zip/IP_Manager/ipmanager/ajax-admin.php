<?php
		define('BASE_PATH', '');
		require_once(BASE_PATH . 'system/core/Bootstrap.php');
		
		$op = @$_GET['op'];
		
		if($op=='accounts_list')
		{
				if(IS_ADMIN)
				{
						$items = whm_get_accts();
						//print_r($items);
						//die('debug');
						$items = whm_sorted_set($items, 'domain');
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
				else
				{
						$all_accts = whm_get_accts();
						$all_accts = whm_sorted_set($all_accts, 'domain');						
						$rsl_accts = whm_get_reseller_accts(CUR_USER);
						if(is_array($rsl_accts))
						{
								foreach($rsl_accts as $k=>$v)
								{
										$domain = $v['domain'];
										if(!isset($all_accts[$domain])) continue;
										$info = $all_accts[$domain];
										foreach($info as $k2=>$v2) if(!isset($rsl_accts[$k][$k2])) $rsl_accts[$k][$k2] = $info[$k2];
								}
						}
						$items = whm_sorted_set($rsl_accts, 'domain');
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
		}
		elseif($op=='ips_list')
		{
				if(IS_ADMIN)
				{
						$used_ips 	= ipm_used_ips();
						// print_r($used_ips);
						$items = whm_get_ips();
						// print_r($items);
						$items = whm_sorted_set($items, 'ip');
						if(!is_array($items)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						$tmp   = array();
						foreach($items as $item)
						{
								if(!in_array($item['ip'], $used_ips)) $tmp[] = $item;
						}
						$items = $tmp;
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
				else
				{
						$used_ips 	= ipm_used_ips();
						$items 		= ipm_get_reseller_ips(CUR_USER);
						$dips  		= ipm_get_dedicated_ips();
						// print_r($items);
						// print_r($dips);
						if(!is_array($items)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						
						$tmp   = array();
						foreach($items as $ip)
						{
								if(in_array($ip, $dips)) // dedicated
								{
										if(!in_array($ip, $used_ips)) $tmp[] = array('ip'=>$ip);
								}
								else // shared
								{
										$tmp[] = array('ip'=>$ip);
								}
						}
						// print_r($tmp);
						$items = $tmp;
						// print_r($items);
						$items = whm_sorted_set($items, 'ip');
						// print_r($items);
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
		}
		elseif($op=='ips_pool')
		{
				if(IS_ADMIN)
				{
						$items = whm_get_ips();
						$items = whm_sorted_set($items, 'ip');
						$dips  = ipm_get_dedicated_ips();
						if(!is_array($items)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						foreach($items as $k=>$v)
						{
								if(in_array($v['ip'], $dips))  	$items[$k]['ipm_dedicated'] = true;
								else 							$items[$k]['ipm_dedicated'] = false;
								$items[$k]['usage_count'] = ipm_ip_usage_count($v['ip']);
						}
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
				else
				{
						$items = array();
						// $items = ipm_get_reseller_ips(CUR_USER);
						// $dips  = ipm_get_dedicated_ips();
						// $tmp   = array();
						// foreach($items as $ip)
						// {
								// $tmp[] = array('ip'=>$ip, 'usage_count'=>ipm_ip_usage_count($ip), 'ipm_dedicated'=>(in_array($ip, $dips) ? true : false));
						// }
						// $items = $tmp;
						// $items = whm_sorted_set($items, 'ip');
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
		}
		elseif($op=='resellers_ips_pool' && @$_GET['type'])
		{
				if(IS_ADMIN)
				{
						$items 		= whm_get_ips();
						$items 		= whm_sorted_set($items, 'ip');
						$dips  		= ipm_get_dedicated_ips();
						$used_ips 	= ipm_get_reseller_all_ips();
						$stat  		= array_count_values($used_ips);
						$tmp		= array();
						if(!is_array($items)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						if($_GET['type']=='shared')
						{
								foreach($items as $k=>$v)
								{
										if(in_array($v['ip'], $dips)) 	continue;
										$items[$k]['ipm_dedicated'] 	= false;
										$items[$k]['usage_count'] 		= ipm_ip_usage_count($v['ip']);
										$items[$k]['resellers_count'] 	= isset($stat[$v['ip']]) ? $stat[$v['ip']] : 0;
										$tmp[] 							= $items[$k];
								}
								$items = $tmp;
								die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						}
						elseif($_GET['type']=='dedicated')
						{
								foreach($items as $k=>$v)
								{
										if(!in_array($v['ip'], $dips) OR in_array($v['ip'], $used_ips)) continue;
										$items[$k]['ipm_dedicated'] 	= true;
										$items[$k]['usage_count'] 		= ipm_ip_usage_count($v['ip']);
										$items[$k]['resellers_count'] 	= isset($stat[$v['ip']]) ? $stat[$v['ip']] : 0;
										$tmp[] 							= $items[$k];
								}
								$items = $tmp;
								die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						}
						else
						{
								foreach($items as $k=>$v)
								{
										$items[$k]['ipm_dedicated'] 	= in_array($v['ip'], $dips) ? true : false;
										$items[$k]['usage_count'] 		= ipm_ip_usage_count($v['ip']);
										$items[$k]['resellers_count'] 	= isset($stat[$v['ip']]) ? $stat[$v['ip']] : 0;
								}
								die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						}
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
		}
		elseif($op=='change_ip_status' && @$_GET['ip'] && @$_GET['status'])
		{
				$usage = ipm_ip_usage_count($_GET['ip']);
				$dips  = ipm_get_dedicated_ips();
				if($_GET['status']=='shared')
				{
						if(!in_array($_GET['ip'], $dips))
						{
								die(json_encode(array('error'=>'This IP address is already shared!', 'op'=>$op)));
						}
						ipm_release_dedicated_ip($_GET['ip']);
				}
				elseif($_GET['status']=='dedicated')
				{
						if($usage>1)
						{
								die(json_encode(array('error'=>'This IP address is currently shared by ' . $usage . ' website'.($usage>1?'s':'').' and cannot be set as dedicated!', 'op'=>$op)));
						}
						if(in_array($_GET['ip'], $dips))
						{
								die(json_encode(array('error'=>'This IP address is already dedicated!', 'op'=>$op)));
						}
						$rsips = ipm_get_reseller_all_ips();
						$stat  = array_count_values($rsips);
						if(isset($stat[$_GET['ip']]) && $stat[$_GET['ip']]>1)
						{
								die(json_encode(array('error'=>'This IP address is currently shared by ' . $stat[$_GET['ip']] . ' resellers and cannot be set as dedicated!', 'op'=>$op)));
						}
						
						ipm_set_dedicated_ip($_GET['ip']);
				}		
				die(json_encode(array('success'=>true, 'op'=>$op)));		
		}
		elseif($op=='assign_reseller_ip' && @$_GET['ip'] && @$_GET['reseller'])
		{
				$ips 			= preg_match('#,#is', $_GET['ip']) ? preg_split('#\s*,\s*#is', $_GET['ip']) : array($_GET['ip']);
				$assigned_ips 	= ipm_get_reseller_all_ips();
				$reseller_ips 	= ipm_get_reseller_ips($_GET['reseller']);
				$dips  			= ipm_get_dedicated_ips();
				if(!is_array($ips)) die(json_encode(array('success'=>true, 'op'=>$op)));
				foreach($ips as $ip)
				{
						if(!in_array($ip, $reseller_ips) && !(in_array($ip, $dips) && in_array($ip, $assigned_ips)) )
						{
								ipm_assign_reseller_ip($_GET['reseller'], $ip);
						}
				}
				die(json_encode(array('success'=>true, 'op'=>$op)));		
		}
		elseif($op=='unassign_reseller_ip' && @$_GET['ip'] && @$_GET['reseller'])
		{
				$ips = preg_match('#,#is', $_GET['ip']) ? preg_split('#\s*,\s*#is', $_GET['ip']) : array($_GET['ip']);
				if(!is_array($ips)) die(json_encode(array('success'=>true, 'op'=>$op)));
				foreach($ips as $ip)
				{
						ipm_unassign_reseller_ip($_GET['reseller'], $ip);
				}
				die(json_encode(array('success'=>true, 'op'=>$op)));		
		}
		elseif($op=='get_reseller_shared_ip' && @$_GET['reseller'])
		{
				if(IS_ADMIN)
				{
						$reseller_ips 	= ipm_get_reseller_ips($_GET['reseller']);
						$dips  			= ipm_get_dedicated_ips();
						$items			= array();
						if(!is_array($reseller_ips)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						foreach($reseller_ips as $ip)
						{
								if(!in_array($ip, $dips))
								{
										$items[] = $ip;
								}
						}
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));	
				}
				else
				{
						$items			= array();
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));	
				}
		}
		elseif($op=='get_reseller_dedicated_ip' && @$_GET['reseller'])
		{
				if(IS_ADMIN)
				{
						$reseller_ips 	= ipm_get_reseller_ips($_GET['reseller']);
						$dips  			= ipm_get_dedicated_ips();
						$items			= array();
						if(!is_array($reseller_ips)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
						foreach($reseller_ips as $ip)
						{
								if(in_array($ip, $dips))
								{
										$items[] = $ip;
								}
						}
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));		
				}
				else
				{
						$items			= array();
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));	
				}				
		}
		elseif($op=='get_free_dedicated_ips')
		{
				$used_ips 	= ipm_get_reseller_all_ips();
				$dips  		= ipm_get_dedicated_ips();
				print_r($used_ips);
				print_r($dips);
				die();
				$items		= array();
				if(!is_array($dips)) die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				foreach($dips as $ip)
				{
						if(!in_array($ip, $used_ips))
						{
								$items[] = $ip;
						}
				}
				die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));		
		}
		elseif($op=='resellers_list')
		{
				if(IS_ADMIN)
				{
						$items = whm_get_resellers();
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
				else
				{
						$items = array();
						die(json_encode(array('success'=>true, 'items'=>$items, 'op'=>$op)));
				}
		}
		elseif($op=='update_domain' && @$_GET['ip'] && @$_GET['user'] && @$_GET['domain'])
		{
				$ret = ipm_update_domain($_GET['ip'], $_GET['user'], $_GET['domain']);
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		elseif($op=='swaip' && @$_GET['domain'] && @$_GET['ip'])
		{
				$ret 	= false;
				$zones  = whm_get_dns_zone($_GET['domain']);
				if(!is_array($zones) OR count($zones)==0)
				{
						log_message('error', "No DNS zone found for domain " . $_GET['domain']);
				}
				else
				{
						$oldip = '';
						if(!is_array($zones)) die(json_encode(array('success'=>true, 'ack'=>$ret, 'op'=>$op)));
						foreach($zones as $zone)
						{
								if ( @$zone['type']=='A' && preg_match('#^'.preg_quote($_GET['domain']).'\.$#is', trim($zone['name'])))
								{
											$oldip = $zone['address'];
											break;
								}
						}
						if($oldip) $ret = ipm_swaip($oldip, $_GET['ip'], $_GET['ip'], $_GET['domain'],$_GET['user']);
				}
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		elseif($op=='rebuild_httpd_conf')
		{
				$ret = ipm_rebuild_httpd_conf();
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		elseif($op=='reboot_apache')
		{
				$ret = ipm_reboot_apache();
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		elseif($op=='log_ip_change' && @$_GET['domain'] && @$_GET['ip'])
		{
				$ret = imp_log_ip_change($_GET['domain'], $_GET['ip']);
				imp_log_user_msg('['.$_GET['domain'].'] ip address changed to ['.$_GET['ip'].']');
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		elseif($op=='ip_change_failed' && @$_GET['domain'] && @$_GET['ip'])
		{
				imp_log_user_msg('['.$_GET['domain'].'] failed ip change to ['.$_GET['ip'].']');
				die(json_encode(array('success'=>true, 'op'=>$op, 'ack'=>$ret)));
		}
		
		die(json_encode(array('exception'=>'malformed request')));
?>
