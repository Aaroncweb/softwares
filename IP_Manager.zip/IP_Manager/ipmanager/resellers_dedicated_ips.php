<?php
		define('BASE_PATH', '');
		require_once(BASE_PATH . 'system/core/Bootstrap.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<meta charset="UTF-8" />
	<title>IP Manager WHM Plugin</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/css/style.css" media="screen" type="text/css" />
	<link rel="stylesheet" href="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/base/jquery-ui.css" />
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
	<script type="text/javascript" src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<script src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/ipmanager.js"></script>
  
  <style type="text/css">
			ul.listing {
					overflow-x:hidden;
					overflow-y:auto;
			}
			.mediumH{
					height:200px;
			}
			.head{
					font-weight:bold;
			}
			ul.listing li {
					width:400px;
					overflow:hidden;
			}
			ul.listing li.listing-row span {
					font-size:1.6em;
			}
			ul.listing li.listing-row span {
					display:block;
					float:left;
					width:100px;
					text-align:right;
			}
			ul.listing li.listing-row span:last-child {
					text-align:left;
					margin-left:20px;
			}
	</style>
  
	<script language="javascript">
		var cur_reseller 	= '';
		var sl_ips 			= [];
		var __base_url = '<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/';
		jQuery(document).ready(function(){
				IPManager.ResellersDIPs.getList(false, 1);
		});
		function quitIpsPopup(reseller, ip){
				$.fancybox.close();
				$('#ip_assign-confirm').remove();
				$('#resellers-list').before('<div style="color:#B94B48;margin-bottom:20px;text-align:center;" id="ip_assign-confirm">Assign <strong>'+ip+'</strong> TO reseller <strong>'+reseller+'</strong>?<br><button onclick="IPManager.Resellers.assignIP(\''+reseller+'\', \''+ip+'\');">CONFIRM</button> <a style="text-decoration:none;" href="javascript:void(0);" onclick="$(\'#ip_assign-confirm\').remove();">(cancel)</a></div>');
		}
		function addIP(reseller, ip){
				if(cur_reseller!=reseller) 
				{
						cur_reseller = reseller;
						sl_ips = [];
				}
				if($.inArray(ip, sl_ips)==-1)
				{
						sl_ips.push(ip);
				}
				$('#ip_assign-confirm').remove();
				var msg = '';
				$.each(sl_ips, function(i, ip){
						msg = msg + (msg ? ', ' : '') + ip;
				});
				if(msg!='')
				{
					$('#resellers-list').before('<div style="color:#B94B48;margin-bottom:20px;text-align:center;" id="ip_assign-confirm">Assign <strong>'+msg+'</strong> TO reseller <strong>'+reseller+'</strong>?<br><button onclick="IPManager.Resellers.assignIP(\''+reseller+'\', \''+msg+'\');">CONFIRM</button> <a style="text-decoration:none;" href="javascript:void(0);" onclick="$(\'#ip_assign-confirm\').remove();">(cancel)</a></div>');
				}
		}
		function removeIP(reseller, ip){
				if($.inArray(ip, sl_ips)>-1)
				{
						sl_ips = $.grep(sl_ips, function(value) {
								return value != ip;
						});
				}
				$('#ip_assign-confirm').remove();
				var msg = '';
				$.each(sl_ips, function(i, ip){
						msg = msg + (msg ? ', ' : '') + ip;
				});
				if(msg!='')
				{
					$('#resellers-list').before('<div style="color:#B94B48;margin-bottom:20px;text-align:center;" id="ip_assign-confirm">Assign <strong>'+msg+'</strong> TO reseller <strong>'+reseller+'</strong>?<br><button onclick="IPManager.Resellers.assignIP(\''+reseller+'\', \''+msg+'\');">CONFIRM</button> <a style="text-decoration:none;" href="javascript:void(0);" onclick="$(\'#ip_assign-confirm\').remove();">(cancel)</a></div>');
				}
		}
		
		function applyAssignments(){
				$.fancybox.close();
				if(sl_ips.length>0)
				{
						ips = "";
						$.each(sl_ips, function(i, ip){
								ips = ips + (ips ? ', ' : '') + ip;
						});
						IPManager.Resellers.assignIP(cur_reseller, ips);
				}
		}
	</script>
  
</head>

<body id="body">
<a href="<?=BASE_URL;?><?=WHM_TOKEN;?>">Back to WHM</a>
<div id="toppromo" style="display:none;">
</div>


<div id="Container">


<div id="Header">
  <div id="Nav" style="line-height: 57px; padding-right: 40px;">
    <h1>IP Manager<?php echo (IS_ADMIN?" - Admin":" - Reseller"); ;?></h1>
   </div>
</div>

<div class="Left">
  <div class="col"> 
  
    <div class="recent">
      <h1>Assign Dedicated IP to resellers</h1>
    </div>
	
	<div id="resellers-list"></div>
	<div id="ips-list" style="margin-top:30px;"></div>
	
  </div>
</div>

<div class="Right">
  <div class="col" style="border: none;">
    <div class="Sidebar">
      <div class="greyoutlinebox">
        <h2>Need help?</h2>
        <p>Check out the <a href="<?=WHM_TOKEN;?>/ipmanager/help.php">FAQs</a></p>
      
		<?php
			if(IS_ADMIN) {
		?>
		
		<h2>IPs Pools</h2>
        <p>
          <a href="<?=WHM_TOKEN;?>/ipmanager/ips_pool.php">Manage Shared/Dedicated IPs</a>
        </p>

		
		<h2>Assign Shared IPs</h2>
        <p>
          <a href="<?=WHM_TOKEN;?>/ipmanager/resellers_shared_ips.php">Assign Shared IP to resellers</a>
        </p>	
		
		<?php
			}
		?>
		
		<h2>Nameservers</h2>
        <p>
          <a href="<?=WHM_TOKEN;?>/ipmanager/custom_nameservers.php">Custom nameservers</a>
        </p>
		
		<?php
			if(IS_ADMIN) {
		?>
		<h2>PHP For Reseller</h2>
        <p>
			Status: <span id="php-rs_on" style="color:#00ff00;<?php echo (PHP_RS=='ON'?'display:inline;':'display:none'); ?>">ON</span> <span id="php-rs_off" style="color:#ff0000;<?php echo (PHP_RS=='OFF'?'display:inline;':'display:none'); ?>">OFF</span>
			(<a href="#" id="php-rs_enable" style="<?php echo (PHP_RS=='OFF'?'display:inline;':'display:none;'); ?>">Enable</a><a href="#" id="php-rs_disable" style="<?php echo (PHP_RS=='ON'?'display:inline;':'display:none;'); ?>">Disable</a><span id="php_rs-act" style="display:none;">&nbsp;<img style="vertical-align:middle;" src="<?php echo WHM_TOKEN; ?>/ipmanager/images/busy.gif" /></span>)
        </p>
		<?php
			}
		?>
		
		<p>
          <a href="<?=WHM_TOKEN;?>/ipmanager/index.php">&laquo; Back home</a>
        </p>
		
	  </div>
    </div>
  </div>
  <img src="http://www.seohost.com/wp-content/themes/seohost/images/logo.png" alt="Logo"/>
</div>


  
<div id="footer">
  Copyright &copy; 2012 SeoHost.com. All rights reserved.<br />
</div>

</div>

</body>

</html>
