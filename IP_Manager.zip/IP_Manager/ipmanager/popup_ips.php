<?php
		define('BASE_PATH', '');
		require_once(BASE_PATH . 'system/core/Bootstrap.php');
		
		$user 	= @$_GET['user'];
		$domain = @$_GET['domain'];
		$ip 	= @$_GET['ip'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta charset="UTF-8" />
	<title>IP Manager WHM Plugin</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/css/style.css" media="screen" type="text/css" />
	<link rel="stylesheet" href="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/themes/base/jquery-ui.css" />
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="<?=PROTO?>://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
	<script type="text/javascript" src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" href="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<script src="<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/assets/js/ipmanager.js"></script>
	<script language="javascript">
		var __base_url 		= '<?=BASE_URL?><?=WHM_TOKEN;?>/ipmanager/';
		var default_user 	= '<?=$user?>';
		var default_domain 	= '<?=$domain?>';
		var default_ip 		= '<?=$ip?>';
		jQuery(document).ready(function(){
				IPManager.IP.getList(false, 1);
		});
	</script>
	<style>
			.noudl {
					text-decoration:none;
			}
			#ips-list ul li {
					font-size:1em;
			}
			#ips-list td {
					padding:0px;
			}
	</style>
</head>

<body id="body">

<div id="toppromo" style="display:none;"></div>

<div>

<h2 style="margin-bottom:25px;text-align:center;">Select new IP address for <?php echo $domain; ?></h2>

<div class="">
  <div class="col">
	 
		<form id="search-form" action="" method="post" onsubmit="IPManager.IP.search();return false;">
			<table id="ips-container" cellspacing="0" cellpadding="0" style="margin-left:auto;margin-right:auto;">
				<tr id="search-container" style="display:none;">
						<td><input type="text" name="q" value=""></td>
						<td><input type="submit" name="bt-search" value="Find"></td>
				</tr>
				<tr id="ips-list" style=""></tr>
			</table>
		</form>
		<script language="javascript">
				$('#search-form').find('input[name="q"]').bind('keyup', function(){ IPManager.IP.search(); });
		</script>
  </div>
</div>
  
<div id="footer">
  Copyright &copy; 2012 SeoHost.com. All rights reserved.<br />
</div>

</div>

</body>

</html>
